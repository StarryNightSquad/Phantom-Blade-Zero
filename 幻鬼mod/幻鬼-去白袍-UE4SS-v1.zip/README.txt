幻鬼 · 去白袍（UE4SS 脚本版）v1
=================================

作用
----
把 NPC「幻鬼」身上那件白色外袍隐藏掉，只留里面的深绿长裙。
不动任何游戏资产：只在她身上把布料组件关掉，删掉 mod 就完全复原。

原理
----
幻鬼的装备不是一整块网格，而是几个独立组件：

  CharacterMesh0            身体
  meshhead                  头
  HuanGui_Lash              睫毛
  CA_SM_HuanGui_cloth01     白色外袍   ← 本 mod 隐藏这个
  CA_SM_HuanGui_cloth02     深绿长裙
  CA_HuanGui_Hair01/02      头发布料
  HuanGui_Pipa/Bowl/Jar     道具

脚本会找到所有 ChaosClothComponent 里名字含 "cloth01" 的那个，做三件事：
  1) SetVisibility(false)          关掉渲染和投影
  2) SetComponentTickEnabled(false) 停掉 Chaos 布料模拟，白袍不再吃性能
  3) 每 2 秒复查一次，过场动画后衣服被重新显示出来会自动再隐藏

安装
----
用 UEModManager 选这个 zip 安装即可。它会放进：
  platform/steam/ue4ss/Mods/PBZHuanGuiNoRobe/

手动安装（如果管理器不认）：
  把 zip 里的 Mods/PBZHuanGuiNoRobe 整个文件夹复制到
  <游戏目录>/platform/steam/ue4ss/Mods/
  确保里面有 Scripts/main.lua 和 enabled.txt。

使用
----
进游戏即生效，不需要按键。
F7 = 显示 / 隐藏白袍（和原版对比用；与另一个 mod 的 F6 不冲突）

卸载
----
管理器里停用/卸载，或直接删掉
  platform/steam/ue4ss/Mods/PBZHuanGuiNoRobe
游戏立即恢复原样。

排查
----
日志：<游戏目录>/platform/steam/ue4ss/UE4SS.log
搜 "PBZHuanGuiNoRobe"，正常会看到：
  [PBZHuanGuiNoRobe] 已处理 1 个白袍组件（启动 3s）
  [PBZHuanGuiNoRobe] 隐藏 -> ChaosClothComponent ...CA_SM_HuanGui_cloth01_GEN_VARIABLE

如果看到「未找到目标组件」，日志会把当前所有 ChaosClothComponent 列出来，
说明组件名或类名和预期不同，把那段发我，我改匹配规则。

注意
----
· 这是 NPC 改造，不是外观系统，不需要外观表（DT），也不影响主角换装。
· 去掉白袍后她是「抹胸长裙 + 露肩臂」的状态，属正常几何，不会破面、不会露空。
· 剧情 CG 里她也会跟着变；如果某些镜头用的是 Sequencer 里单独摆的副本，
  脚本的 2 秒复查会兜住。
· 只影响本地显示，不改存档。
