--[[
    PBZHuanGuiNoRobe
    隐藏幻鬼（BP_NPC_HuanGui）身上的白外袍：组件 CA_SM_HuanGui_cloth01。

    只隐藏组件，不改任何资产：
      · SetVisibility(false) 关渲染与投影
      · SetComponentTickEnabled(false) 停掉 Chaos 布料模拟，省性能
      · 每 2 秒复查可见性，过场 / Sequencer 把衣服重新显示出来后自动再隐藏
      · 每 15 秒重扫一次，抓住新生成的 NPC
      · F7 手动切换，方便和原版对比

    依赖：UE4SS（游戏自带）。不改 pak、不动存档、可随时删除。
]]

local MOD_NAME  = "PBZHuanGuiNoRobe"
local TARGET    = "cloth01"                                                    -- 组件全名里包含这个就算目标
local BP_CLASS  = "/Game/PBZContent/Blueprint/Character/NPC/FlowNpc/BP_NPC_HuanGui.BP_NPC_HuanGui_C"
local TOGGLE_KEY = Key and Key.F7 or nil

local enabled = true          -- true = 隐藏白袍
local cache   = {}            -- 已找到的组件
local state   = {}            -- 上次应用的可见性，避免重复写日志
local last_rehide = 0         -- 上次"被重新显示"的提示时间，限流用

local function log(fmt, ...)
    local ok, s = pcall(string.format, fmt, ...)
    print("[" .. MOD_NAME .. "] " .. (ok and s or tostring(fmt)) .. "\n")
end

local function is_valid(obj)
    if obj == nil then return false end
    local ok, r = pcall(function() return obj:IsValid() end)
    return ok and r and true or false
end

local function fname(obj)
    local ok, n = pcall(function() return obj:GetFullName() end)
    return (ok and n) or "?"
end

-- 对单个组件应用当前开关状态
local function apply(comp, quiet)
    if not is_valid(comp) then return end
    local nm = fname(comp)
    if state[nm] == enabled then return end
    state[nm] = enabled

    -- 注意：不要写 enabled and false or true —— Lua 里 true and false or true 结果是 true
    local show = not enabled
    pcall(function() comp:SetVisibility(show, true) end)
    pcall(function() comp:SetHiddenInGame(not show) end)
    pcall(function() comp:SetComponentTickEnabled(show) end)

    if not quiet then
        log("%s -> %s", enabled and "隐藏" or "恢复", nm)
    end
end

-- 扫描所有 ChaosClothComponent，挑出白袍
local function scan(quiet)
    local found = {}
    local ok, all = pcall(FindAllOf, "ChaosClothComponent")
    if not ok or not all then
        if not quiet then log("FindAllOf 失败：%s", tostring(all)) end
        return found
    end
    local names = {}
    for i = 1, #all do
        local c = all[i]
        local nm = fname(c)
        names[#names + 1] = nm
        if string.find(nm, TARGET, 1, true) then
            found[#found + 1] = c
        end
    end
    if #found == 0 and not quiet then
        log("未找到目标组件。当前 ChaosClothComponent 共 %d 个：", #names)
        for i = 1, #names do log("  - %s", names[i]) end
    end
    return found
end

local function refresh(reason, quiet)
    local list = scan(quiet)
    if #list > 0 then
        cache = list
        for i = 1, #list do apply(list[i]) end
        if not quiet then log("已处理 %d 个白袍组件（%s）", #list, reason or "") end
    elseif not quiet then
        log("本次未命中（%s），继续等待 NPC 生成", reason or "")
    end
end

-- ---------- 启动 ----------
log("加载中…… 目标组件关键字 = %s", TARGET)

-- 新 NPC 生成时立刻处理（构造完成后再等半秒，确保组件已建好）
local okN, errN = pcall(NotifyOnNewObject, BP_CLASS, function(_obj)
    ExecuteWithDelay(600, function() refresh("新 NPC 生成", false) end)
end)
if not okN then
    log("NotifyOnNewObject 注册失败（%s），将依赖定时扫描", tostring(errN))
end

-- 定时轻量复查：只检查已缓存的组件是否被重新显示
LoopAsync(2000, function()
    for i = 1, #cache do
        local c = cache[i]
        if is_valid(c) then
            local vis = true
            pcall(function() vis = c:IsVisible() end)
            if enabled and vis then
                state[fname(c)] = nil          -- 强制重新应用
                apply(c, true)                 -- 静默，避免刷屏
                local now = os and os.time and os.time() or 0
                if now - (last_rehide or 0) > 60 then
                    last_rehide = now
                    log("检测到白袍被重新显示，已再次隐藏")
                end
            end
        end
    end
    return false
end)

-- 定时全量重扫，抓新生成的实例
LoopAsync(15000, function()
    refresh("定时重扫", true)
    return false
end)

-- ---------- F7 切换 ----------
local function toggle()
    enabled = not enabled
    state = {}
    log("手动切换：%s", enabled and "隐藏白袍" or "显式复原")
    refresh("F7", false)
end

if TOGGLE_KEY then
    local ok1 = pcall(RegisterKeyBind, TOGGLE_KEY, {}, toggle)
    if not ok1 then
        local ok2 = pcall(RegisterKeyBind, TOGGLE_KEY, toggle)
        if not ok2 then
            local ok3 = pcall(RegisterKeyBindAsync, TOGGLE_KEY, {}, toggle)
            if not ok3 then log("F7 绑定失败，脚本仍会按默认状态生效") end
        end
    end
end

-- 进游戏后补一次（世界加载需要几秒）
ExecuteWithDelay(3000, function() refresh("启动 3s", false) end)
ExecuteWithDelay(12000, function() refresh("启动 12s", true) end)

log("就绪。F7 = 显示/隐藏白袍")
