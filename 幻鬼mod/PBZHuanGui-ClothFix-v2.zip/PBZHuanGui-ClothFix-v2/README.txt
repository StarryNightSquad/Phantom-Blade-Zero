幻鬼去衣 —— UE4SS 补丁 修复版 v2
=====================================

包内两个 mod：

  PBZHuanGuiNoRobe   隐藏幻鬼白外袍（组件 CA_SM_HuanGui_cloth01）   热键 F7
  PBZHuanGuiNoDress  隐藏幻鬼深绿长裙（组件 CA_SM_HuanGui_cloth02） 热键 F8

F7 / F8 是分开的，两个 mod 可以同时开，互不抢键。


怎么装
------

把 PBZHuanGuiNoRobe 和 PBZHuanGuiNoDress 两个文件夹，
整个复制到：

    <游戏目录>\platform\steam\ue4ss\Mods\

放好后路径应该是：
    ...\ue4ss\Mods\PBZHuanGuiNoRobe\Scripts\main.lua
    ...\ue4ss\Mods\PBZHuanGuiNoDress\Scripts\main.lua

每个 mod 文件夹里都有一个空的 enabled.txt，它本身就是"已启用"的标记，
不要删。想临时关掉某个 mod，把这个 enabled.txt 删掉或改名即可。

只想要其中一个：只复制对应的那一个文件夹就行。


这版修了什么
------------

旧版（v1）在切关卡时会闪退，弹 "Fatal Error! Crashdump written to: ..."。

原因是旧版把组件指针长期缓存下来，每 2 秒去读一次它的可见性。
切关卡后旧关卡的 Actor 已经被销毁，缓存里还是那块已经被回收的内存，
UE4SS 的属性绑定层于是解引用空指针（UE4SS.dll+0x2BCB3D，读地址 0x0）。
这是 native 层崩溃，Lua 的 pcall 拦不住，所以日志看着完全正常，游戏却直接没了。

这版做了四件事：

  1. 地图门控：幻鬼只在庞镇出现，所以只在这张地图工作。
     地图状态由游戏的切图事件推过来（监听 UEngine::LoadMap 的前后回调），
     不主动轮询。不在庞镇时，定时器只读一个 Lua 布尔值就返回，零引擎调用。
  2. 不跨帧持有指针：每次扫描现取现用，用完即扔，只把组件名字（字符串）记下来。
  3. 切图后静默一次扫描，避开 World 刚加载、Actor 还没就位的那几秒。
  4. 每个 UObject 调用单独 pcall，一个组件出问题不影响其它组件。


怎么确认它在工作
----------------

进庞镇后，UE4SS.log 里会出现：

    [PBZHuanGuiNoRobe] 地图（切图）：/Game/Maps/B08_09_10/PBZ_Pangzhen_WP... —— 庞镇，启用
    [PBZHuanGuiNoRobe] 隐藏 -> CA_SM_HuanGui_cloth01

    [PBZHuanGuiNoDress] 地图（切图）：/Game/Maps/B08_09_10/PBZ_Pangzhen_WP... —— 庞镇，启用
    [PBZHuanGuiNoDress] 隐藏 -> CA_SM_HuanGui_cloth02

切到别的地图会显示 "非庞镇，休眠"，之后完全不动任何游戏对象。

非庞镇时按 F7 / F8 会提示"开关已记录，进庞镇后生效"，不会误以为按键坏了。


如果裙子没消失
--------------

长裙那个 mod 的目标组件名 cloth02 是从旧代码注释来的，实际没在日志里跑出来过
（这个 mod 装上后很快就被禁用了）。如果进庞镇后日志显示"本次未命中"，
它会把当前所有 ChaosClothComponent 的名字列出来，把那段列表发出来就能校准。

白袍那个 mod 是验证过的，日志里确实出现过 CA_SM_HuanGui_cloth01。


其他
----

改过的脚本都在各自文件夹里，想恢复原版就把 Scripts\main.lua 删掉。
不改 pak、不动存档、随时可以整个文件夹删掉。
