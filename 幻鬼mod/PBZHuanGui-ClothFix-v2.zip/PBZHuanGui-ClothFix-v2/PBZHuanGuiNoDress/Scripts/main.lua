--[[
    PBZHuanGuiNoDress  v2
    隐藏幻鬼（BP_NPC_HuanGui）身上的深绿长裙：组件 CA_SM_HuanGui_cloth02。

    ── v1 的隐患（和去白袍 mod v1 完全同源）─────────────────────
      v1 把组件指针长期存在 cache 里，每 2 秒对缓存逐个访问（IsVisible / GetFullName）。
      切关卡时旧关卡的 Actor 已销毁，cache 仍指着那块内存 → UE4SS 属性绑定层空指针，
      native 崩溃，pcall 拦不住。日志看着一切正常，游戏却直接闪退。

    ── v2 的做法：地图状态靠"推"，不靠"问" ──────────────────────
      1) 监听 UEngine::LoadMap 的 Pre/Post 回调，由游戏在切图时把新 World 交过来，
         读一次全名判断是不是庞镇（PBZ_Pangzhen_WP），记进 active。
      2) 平时不主动查询任何东西。active == false 时定时器只读一个 Lua 布尔值就返回，
         全程零引擎调用 —— 不在庞镇时这个 mod 等于不存在。
      3) 不跨帧持有指针：每次扫描现取现用，只把组件名字（字符串）记在纯 Lua 表里。
      4) 切图后静默一次扫描，避开 World 刚加载、Actor 还没就位的窗口。
      5) 每个 UObject 调用单独 pcall，一个组件出问题不影响其它组件。

      唯一一次"主动读"在启动后 4 秒，用于「热重载时人已在庞镇」的情况；
      若之前已收到切图事件就跳过。之后全靠事件驱动。

      想改成所有地图生效：把 MAP_KEY 改成 nil 或 ""。

    依赖：UE4SS（游戏自带）。不改 pak、不动存档、可随时删除。
]]

local MOD_NAME = "PBZHuanGuiNoDress"
local TARGET   = "cloth02"    -- 组件名里包含这个就算目标（深绿长裙）
local MAP_KEY  = "Pangzhen"   -- 只在这张地图工作
local BP_CLASS = "/Game/PBZContent/Blueprint/Character/NPC/FlowNpc/BP_NPC_HuanGui.BP_NPC_HuanGui_C"
local SCAN_MS  = 3000
local SKIP_TICKS = 1

local enabled      = true
local hidden       = {}
local skip         = 0
local ticks        = 0
local last_note    = 0
local busy         = false

local active       = false
local active_known = false

-- 去白袍那个 mod 用 F7，这里用 F8，避免两个 mod 抢同一个键
local TOGGLE_KEY = Key and Key.F8 or nil

local function log(fmt, ...)
    local ok, s = pcall(string.format, fmt, ...)
    print("[" .. MOD_NAME .. "] " .. (ok and s or tostring(fmt)) .. "\n")
end

local function valid(o)
    if o == nil then return false end
    if type(IsValid) == "function" then
        local ok, r = pcall(IsValid, o)
        if ok then return r == true end
    end
    local ok, r = pcall(function() return o:IsValid() end)
    return ok and r == true
end

-- ---------- 地图：由切图事件推过来 ----------
local function unwrap(x)
    if x == nil then return nil end
    local ok, v = pcall(function() return x:get() end)
    if ok and v ~= nil then return v end
    return x
end

local function fullname_of(obj)
    if obj == nil then return nil end
    local ok, n = pcall(function() return obj:GetFullName() end)
    if ok and type(n) == "string" and n ~= "" then return n end
    return nil
end

local function is_target_name(full)
    if MAP_KEY == nil or MAP_KEY == "" then return true end
    return full ~= nil and string.find(full, MAP_KEY, 1, true) ~= nil
end

local function apply_map(full, source)
    hidden = {}
    if full == nil then
        active = false
        log("地图（%s）：读不到名字，休眠并等下一次切换", source)
        return
    end
    active = is_target_name(full)
    active_known = true
    if active then
        log("地图（%s）：%s —— 庞镇，启用", source, full)
    else
        log("地图（%s）：%s —— 非庞镇，休眠", source, full)
    end
end

-- ---------- 扫描 ----------
local function apply(c, nm)
    if not valid(c) then return end

    local okv, vis = pcall(function() return c:IsVisible() end)
    if not okv then return end
    if hidden[nm] and vis == false then return end

    pcall(function() c:SetVisibility(false, true) end)
    pcall(function() c:SetHiddenInGame(true) end)
    pcall(function() c:SetComponentTickEnabled(false) end)

    if not hidden[nm] then
        hidden[nm] = true
        log("隐藏 -> %s", nm)
    else
        if ticks - last_note > 20 then
            last_note = ticks
            log("长裙被重新显示，已再次隐藏")
        end
    end
end

local function scan(quiet, reason)
    if busy then return end
    busy = true

    local ok, err = pcall(function()
        local okf, all = pcall(FindAllOf, "ChaosClothComponent")
        if not okf or all == nil then
            if not quiet then log("FindAllOf 失败：%s", tostring(all)) end
            return
        end
        local okn, n = pcall(function() return #all end)
        if not okn or type(n) ~= "number" then
            if not quiet then log("FindAllOf 返回了非列表结果") end
            return
        end

        local hit, total, names = 0, 0, {}
        for i = 1, n do
            local c = all[i]
            total = total + 1
            local ok2, nm = pcall(function() return c:GetName() end)
            if ok2 and type(nm) == "string" then
                names[#names + 1] = nm
                if string.find(nm, TARGET, 1, true) then
                    hit = hit + 1
                    apply(c, nm)
                end
            end
        end

        if hit == 0 and not quiet then
            log("本次未命中（%s），ChaosClothComponent 共 %d 个：", reason or "", total)
            for i = 1, #names do log("  - %s", names[i]) end
            log("若上面列表里没有 %s，说明组件名不是这个，把列表发出来即可校准。", TARGET)
        elseif hit > 0 and not quiet then
            log("已处理 %d 个长裙组件（%s）", hit, reason or "")
        end
    end)

    busy = false
    if not ok then log("扫描异常：%s", tostring(err)) end
end

local function tick(quiet, reason)
    ticks = ticks + 1

    if not active then
        if not active_known and ticks == 20 then
            log("60 秒没收到任何地图信息，mod 处于待命（不会碰游戏对象）")
        end
        return
    end

    if skip > 0 then
        skip = skip - 1
        return
    end
    scan(quiet, reason)
end

-- ---------- 切图事件 ----------
local okPre = pcall(RegisterLoadMapPreHook, function()
    pcall(function()
        active = false
        hidden = {}
    end)
end)

local okPost = pcall(RegisterLoadMapPostHook, function(_engine, world)
    pcall(function()
        local full = fullname_of(unwrap(world))
        if full == nil then
            local okw, w = pcall(FindFirstOf, "World")
            full = okw and fullname_of(w) or nil
        end
        apply_map(full, "切图")
        skip = SKIP_TICKS
    end)
end)

if not okPre then log("RegisterLoadMapPreHook 不可用") end
if not okPost then log("RegisterLoadMapPostHook 不可用") end

-- ---------- 启动 ----------
log("加载中…… 目标组件 = %s，地图门控 = %s（靠切图事件驱动）", TARGET, tostring(MAP_KEY))

local okN, errN = pcall(NotifyOnNewObject, BP_CLASS, function(_obj)
    ExecuteWithDelay(800, function() pcall(tick, false, "新 NPC 生成") end)
end)
if not okN then
    log("NotifyOnNewObject 注册失败（%s），将依赖定时扫描", tostring(errN))
end

LoopAsync(SCAN_MS, function()
    pcall(tick, true, "定时")
    return false
end)

-- ---------- F8 切换 ----------
local function toggle()
    enabled = not enabled
    hidden = {}
    log("手动切换：%s", enabled and "隐藏长裙" or "恢复显示")
    if not active then
        log("当前不在庞镇，开关已记录，进庞镇后生效")
        return
    end
    if enabled then pcall(tick, false, "F8") end
end

if TOGGLE_KEY then
    local ok1 = pcall(RegisterKeyBind, TOGGLE_KEY, {}, toggle)
    if not ok1 then
        local ok2 = pcall(RegisterKeyBind, TOGGLE_KEY, toggle)
        if not ok2 then log("F8 绑定失败，脚本仍会按默认状态生效") end
    end
end

ExecuteWithDelay(4000, function()
    pcall(function()
        if active_known then return end
        local okw, w = pcall(FindFirstOf, "World")
        local full = okw and fullname_of(w) or nil
        if full ~= nil then
            apply_map(full, "启动探测")
        else
            log("启动时没取到地图名，等待切图事件")
        end
    end)
    pcall(tick, false, "启动 4s")
end)

log("就绪（v2：切图事件驱动 + 地图门控 + 不持指针）。F8 = 显示/隐藏长裙")
