-- PBZFlashStepSpace 0.4.0 | Steam build CL-301524 / UE 5.7.4
--
-- 只做两件事，其它一概不动：
--   (1) 新增  右键 + 空格   → 瞬身
--   (2) 禁用  右键 + 左Shift → 瞬身（左Shift 只剩普通闪避）
--
-- 依据（本 build 已实测的输入结构，来自 318 的源码）：
--   瞬身与普通闪避共用同一个原生动作 /PBZDeflectSystem/Input/IA_Dodge，
--   区别只在该动作绑定行的 TriggerTag：
--     · 普通闪避 = TriggerTag 不等于 Ability.Action.Hun.SpecialDash
--     · 瞬身     = TriggerTag 等于 Ability.Action.Hun.SpecialDash（并要求按住右键的架势 tag）
--
-- 做法（0.4.0 起：不动任何 IMC 映射行，只重排「绑定内容」）：
--   · 原生 IA_Dodge 的每个绑定源按 TriggerTag 拆成两份 ——
--       普通行留在 IA_Dodge 上（它的键位仍是一开始的 Shift + RB，一个都没变）
--       瞬身行搬进私有动作 PBZFS_SpecialDash
--   · 自建 InputMappingContext（优先级 100）把 SpaceBar 映射到那个私有动作，
--     并且只在按住右键时挂载 —— 空格平时仍然是跳跃。
--
-- 为什么必须这样（0.2.x~0.3.x 的教训）：
--   教程 QTE 的判定是「读 IA_Dodge 绑定的键，要求玩家按下它」，不是「检测闪避动作」。
--   改映射行会让 IA_Dodge 丢掉 Shift，我们的空格上下文又给它加上空格 →
--   QTE 查到「Shift + 空格」两个键 → 提示来回跳、必须两个一起按。
--   现在 IA_Dodge 的键位集合完全没动，QTE 看到的还是 Shift。
--
--   不删技能、不改数值/存档、不碰 K2_CanActivateAbility、不动其它按键。
local MOD = 'PBZFlashStepSpace'
local TRIGGER = 'SpaceBar'
local MODIFIER = 'RightMouseButton'
local SUPPRESS_KEY = 'LeftShift' -- 要移除瞬身语义的物理键（默认键位）
local PRIORITY = 100
local DEVICE_ID = 1 -- 键盘鼠标
local DODGE_PATH = '/PBZDeflectSystem/Input/IA_Dodge.IA_Dodge'
local DEFLECT_CTX = '/PBZInput/IMC_Deflect.IMC_Deflect'
local DEFAULT_CTX = '/PBZInput/IMC_Default.IMC_Default'
local BASE_BINDING = '/PBZCombatAsset/ActorData/Players/Hun/InputMap/AIM_Hun_Dash.AIM_Hun_Dash'
local SPECIAL = 'Ability.Action.Hun.SpecialDash'

local function log(s) print('[' .. MOD .. '] ' .. s .. '\n') end
if type(LoopInGameThreadWithDelay) ~= 'function' then
    log('DISABLED: game-thread timer unavailable')
    return
end

local function valid(o) return o ~= nil and o:IsValid() end
local function equal(a, b) return valid(a) and valid(b) and a:GetAddress() == b:GetAddress() end
local function unwrap(v) local ok, x = pcall(function() return v:get() end); return ok and x or v end
local function key(name) return { KeyName = FName(name) } end
local function full(o) local n = o:GetFullName(); return n:match('^%S+ (.+)$') or n end
local function each(a, fn)
    if a == nil then return end
    if type(a) == 'table' and type(a.ForEach) ~= 'function' then
        for i, v in ipairs(a) do fn(i, v) end
    else
        a:ForEach(function(i, v) fn(i, unwrap(v)) end)
    end
end
-- 按名字识别本 mod 造的私有动作。换人/换组件后旧对象可能已失效，
-- 但 IMC 行里还留着它的引用，靠名字才能把它们捞回来重定向。
local function isOurs(action)
    if not action then return false end
    local ok, name = pcall(function() return action:GetFullName() end)
    if not ok or type(name) ~= 'string' then return false end
    return name:find('PBZFS_PlainDodge_', 1, true) ~= nil
        or name:find('PBZFS_SpecialDash_', 1, true) ~= nil
end

local function array(a)
    local r = {}
    each(a, function(_, v) if v ~= nil then r[#r + 1] = v end end)
    return r
end

-- 帧循环里反复用到的 FKey 预先构造好：FName 走全局名字表，
-- 每帧新建一次是纯浪费，这里只建一次。
local K_MODIFIER = { KeyName = FName(MODIFIER) }
local K_TRIGGER = { KeyName = FName(TRIGGER) }
local K_SUPPRESS = { KeyName = FName(SUPPRESS_KEY) }

local options = { bIgnoreAllPressedKeysUntilRelease = true, bForceImmediately = true, bNotifyUserSettings = false }
local pc, pawn, pawnFull, component, sub, stats, dodge, outer, serial
local spaceCtx, plainAction, specialAction, plainBindings, specialBindings
local mapped, stopped, diagnosed = false, false, false
local guardInstalled = false
local retargets = 0
local componentAddr   -- 当前接管所依附的 InputComponent 身份，用来发现组件被换掉
local worldLoading = false  -- 切图进行中（LoadMapPre 到 Post）
local holdUntil = 0         -- 恢复接管的帧号（切图结束后再等几秒，避开销毁/生成高峰）
local consumeSaved, consumeDirty

local function make(class, label, template)
    local cl = StaticFindObject(class)
    assert(valid(cl), 'Missing class ' .. class)
    serial = (serial or 0) + 1
    local o = StaticConstructObject(cl, outer, FName('PBZFS_' .. label .. '_' .. serial, EFindName.FNAME_Add),
        0x40, 0x40000000, false, false, template)
    assert(valid(o), 'Cannot construct ' .. label)
    return o
end

local function playerFrom(c)
    local ok, p, name = pcall(function()
        if not valid(c) then return end
        -- IsLocalController 是原生调用，某些时刻会抛错；单独保护，
        -- 否则一次抛错会把下面整个查找结果一起丢掉。
        local lok, isLocal = pcall(function() return c:IsLocalController() end)
        if not (lok and isLocal) then return end
        local pok, p = pcall(function() return c.Pawn end)
        if not (pok and valid(p)) then return end
        local nok, n = pcall(function() return p:GetFullName() end)
        if not (nok and type(n) == 'string') then n = '(unknown pawn)' end
        -- 首选：主流程玩家本体，以及二周目开局的「青年魂」（Young Hun）。
        -- 青年魂在本 build 里是 BP_Seq_Young_Hun_C 一系，类名与主流程不同，
        -- 只认 BP_Renewal_Hun_C 会让二周目整局漏掉（见 0.3.5 修复）。
        if n:find('PersistentLevel.BP_Renewal_Hun_C_', 1, true)
            or n:find('Young_Hun', 1, true) then
            return p, n
        end
        -- 回退：本地控制器持有的、且确实带能力输入组件的 Pawn。
        -- 只认类名会在「可操控角色被换成别的蓝图」时整局漏掉 —— 二周目开局
        -- （竹林古屋 / 青年 Hun）就是这种情况：日志在 local player 之后
        -- 再也不出现任何一行，Shift 全程按不出来。
        local cok, comp = pcall(function() return p:GetAbilityInputComponent() end)
        if cok and valid(comp) then return p, n end
    end)
    if ok and p then return c, p, name end
end

local function currentPlayer()
    local c, p, name = playerFrom(pc)
    if c then return c, p, name end
    local ok, list = pcall(FindAllOf, 'PlayerController')
    if not ok or list == nil then return end
    for _, candidate in ipairs(list) do
        c, p, name = playerFrom(candidate)
        if c then return c, p, name end
    end
end

local function findSub()
    local outerPlayer = nil
    pcall(function() outerPlayer = pc.Player end)
    if not valid(outerPlayer) then return end
    local ok, list = pcall(FindAllOf, 'EnhancedInputLocalPlayerSubsystem')
    if not ok then return end
    for _, s in ipairs(list) do
        local matched = false
        pcall(function() matched = valid(s) and equal(s:GetOuter(), outerPlayer) end)
        if matched then return s end
    end
end

-- 记录「本次为什么没接管成功」。ensureRefs 有 6 个提前 return 分支，
-- 没有这个变量时，任何一处失败都表现为「日志里什么都没有」——二周目那次
-- 就是这样整整静默了 5 分钟，完全无法定位。
local refBlock = 'init'

local function ensureRefs()
    if not (valid(pc) and valid(pawn)) then refBlock = 'no player'; return false end
    if not valid(stats) then
        stats = StaticFindObject('/Script/Engine.Default__GameplayStatics')
        if not valid(stats) then refBlock = 'GameplayStatics 缺失'; return false end
    end
    if not valid(dodge) then
        dodge = StaticFindObject(DODGE_PATH)
        if not valid(dodge) then refBlock = 'IA_Dodge 资产缺失'; return false end
    end
    if not valid(outer) then
        outer = pc.Player
        if not valid(outer) then refBlock = 'LocalPlayer 缺失'; return false end
    end
    if not valid(component) then
        component = pawn:GetAbilityInputComponent()
        if not valid(component) then refBlock = '能力输入组件缺失'; return false end
    end
    if not valid(sub) then
        sub = findSub()
        if not valid(sub) then refBlock = '输入子系统缺失'; return false end
    end
    -- 原生动作还没注册到能力输入组件上，说明还没进可操作状态。
    -- 换图后 IA_Dodge 可能被重载成另一个对象，此时旧引用仍 valid 但已不在
    -- InputBindings 里 —— 不重新解析就会永久卡死在这一行（同样静默）。
    local has = false
    pcall(function() has = component.InputBindings:Contains(dodge) end)
    if not has then
        local okFresh, fresh = pcall(StaticFindObject, DODGE_PATH)
        if okFresh and valid(fresh) and not equal(fresh, dodge) then
            dodge = fresh
            pcall(function() has = component.InputBindings:Contains(dodge) end)
        end
    end
    if not has then refBlock = 'IA_Dodge 未注册到组件'; return false end
    refBlock = 'ok'
    return true
end

-- ==================== (2) 让左Shift不再触发瞬身 ====================

-- 只保留非瞬身行。读不出 TriggerTag 的行一律保留：宁可多留，不可误删。
-- fallback：条件桶里一条普通行都不剩时，用 NormalData 的普通行补上。
--   原因：瞬身行挂在「按住右键」的条件桶里。若该桶原本只有瞬身行，
--   摘掉后桶就空了，按住右键反而变得什么都按不出来 —— 那不是"禁用瞬身"，
--   而是把闪避一起弄坏了。补上后：右键+Shift 稳定退回普通闪避。
local function filterRows(data, keepSpecial, fallback)
    local left = 0
    for _, field in ipairs({ 'Actions', 'Combos', 'InterruptLower' }) do
        local kept = {}
        each(data[field], function(_, row)
            local ok, tag = pcall(function() return row.TriggerTag.TagName:ToString() end)
            local isSpecial = ok and tag == SPECIAL
            if isSpecial == keepSpecial then kept[#kept + 1] = row end
        end)
        data[field] = kept
        left = left + #kept
    end
    if left == 0 and fallback then
        for _, field in ipairs({ 'Actions', 'Combos', 'InterruptLower' }) do
            data[field] = array(fallback[field])
        end
        return 'filled'
    end
end

-- keepSpecial=false：只留普通闪避行（给原生 IA_Dodge 用）
-- keepSpecial=true ：只留瞬身行      （给空格触发的私有动作用）
local function cloneBinding(source, label, keepSpecial)
    local copy = make('/Script/SGameInputSystem.InputActionBinding', label, source)
    each(copy.Bindings, function(_, entry)
        filterRows(entry.NormalData, keepSpecial, nil)
        entry.TagConditionData:ForEach(function(k, v)
            -- 只有普通行那种副本才需要 fallback：桶被清空会让「按住右键」变成无反应。
            local how = filterRows(unwrap(v), keepSpecial, keepSpecial and nil or entry.NormalData)
            if how == 'filled' then
                local ok, name = pcall(function() return unwrap(k).TagName:ToString() end)
                log('  条件桶 ' .. tostring(ok and name or k) .. ' 已无普通行，用普通行补上（保持按住右键可闪避）')
            end
        end)
    end)
    return copy
end

-- 这个绑定源里是否存在「瞬身行」（TriggerTag == Ability.Action.Hun.SpecialDash）。
-- 只要存在，右键+Shift 就会命中瞬身 —— 这就是必须替换掉它的判据。
local function hasSpecialRow(source)
    local found = false
    pcall(function()
        each(source.Bindings, function(_, entry)
            if found then return end
            local function scan(data)
                for _, field in ipairs({ 'Actions', 'Combos', 'InterruptLower' }) do
                    each(data[field], function(_, row)
                        local ok, tag = pcall(function() return row.TriggerTag.TagName:ToString() end)
                        if ok and tag == SPECIAL then found = true end
                    end)
                end
            end
            scan(entry.NormalData)
            entry.TagConditionData:ForEach(function(_, v) scan(unwrap(v)) end)
        end)
    end)
    return found
end

-- 枚举可能存放 IA_Dodge 映射行的容器：当前生效的上下文 + 两个关键 IMC 资产；
-- 每个容器再展开 MappingProfileOverrides（游戏内键位档案就存在这里）。
-- 整段必须全程 pcall：切图瞬间 PlayerInput.AppliedInputContextData 会短暂变成非映射对象，
-- 直接 :ForEach 会抛错 → tick 触发禁用 → 行留在私有动作上 → 闪避彻底失效（v0.3.2 的坑）。
local function collectRowSets()
    local sets, seen, applied = {}, {}, 0

    local function addContext(c, label)
        if not valid(c) then return end
        pcall(function()
            local addr = c:GetAddress()
            if not addr or seen[addr] then return end
            seen[addr] = true
            sets[#sets + 1] = { rows = c.DefaultKeyMappings.Mappings, label = label .. ' default' }
            local overrides = c.MappingProfileOverrides
            if overrides ~= nil then
                pcall(function()
                    overrides:ForEach(function(k, p)
                        local pr = unwrap(p)
                        if valid(pr) then
                            sets[#sets + 1] = { rows = pr.Mappings, label = label .. ' profile=' .. tostring(k) }
                        end
                    end)
                end)
            end
        end)
    end

    local function collect(field)
        pcall(function()
            local map = pc.PlayerInput[field]
            if map == nil then return end
            pcall(function()
                map:ForEach(function(k)
                    local c = unwrap(k)
                    if valid(c) and not equal(c, spaceCtx) then
                        applied = applied + 1
                        addContext(c, full(c))
                    end
                end)
            end)
        end)
    end

    collect('AppliedInputContextData')
    if applied == 0 then collect('AppliedInputContexts') end
    for _, path in ipairs({ DEFLECT_CTX, DEFAULT_CTX }) do
        local c = StaticFindObject(path)
        if valid(c) then addContext(c, full(c)) end
    end
    return sets
end

-- 重建玩家映射。必须等按键全部松开再做：重建会刷掉原生 Pressed 触发器，
-- 若此时按键正被按住，一次物理按下会被算成两次。318 的源码里专门为此写了注释。
local function rebuild()
    if not valid(sub) then return false end
    local ok = pcall(function() sub:RequestRebuildControlMappings(options, DEVICE_ID) end)
    if not ok then log('WARN: RequestRebuildControlMappings failed') end
    return ok
end

local function keysReleased()
    for _, k in ipairs({ K_MODIFIER, K_TRIGGER, K_SUPPRESS }) do
        local ok, down = pcall(function() return pc:IsInputKeyDown(k) end)
        if not ok or down then return false end
    end
    return true
end

-- 读原生 IA_Dodge 当前挂着的绑定源。
-- 关键：游戏会按武器动态增删这些源（魔剑有 AIM_Mojian_Dash，别的武器还有各自的），
-- 所以任何时刻都必须重新读，不能装完一次就缓存住。
local function sourceList()
    if not (valid(component) and valid(dodge)) then return nil end
    if not component.InputBindings:Contains(dodge) then return nil end
    local list = array(component.InputBindings:Find(dodge):get().Bindings)
    if #list == 0 then return nil end
    return list
end

-- 组件上这个动作实际挂着几份绑定源。
-- Contains() 在组件被重建后可能仍返回 true 但数组已空 —— 那种状态下 Shift 会按不出任何东西，
-- 所以这里按数量判断，比 Contains 可靠。
local function bindingCount(action)
    if not valid(component) or not valid(action) then return 0 end
    local n = 0
    pcall(function()
        local rec = component.InputBindings:Find(action)
        if rec == nil then return end
        local inner = nil
        pcall(function() inner = rec:get() end)
        if inner == nil then inner = rec end
        if inner ~= nil then n = #array(inner.Bindings) end
    end)
    return n
end

-- ============ 核心：把「瞬身行」从原生动作里挪出来 ============
--
-- 为什么不用「改 IMC 映射行」那套（0.2.x ~ 0.3.x）：
--   教程 QTE 的判定是「读 IA_Dodge 绑定的键，要求玩家按下它」，不是「检测闪避动作」。
--   改映射行会让 IA_Dodge 丢掉 Shift、同时我们的空格上下文又给它加上空格，
--   于是 QTE 查到「Shift + 空格」两个键，提示来回跳、且必须两个一起按。
--
-- 现在改成不动任何映射行：
--   原生 IA_Dodge   → 键位保持 Shift + RB（QTE 满意），但绑定内容换成「只含普通行」
--   私有 SpecialDash→ 绑定内容「只含瞬身行」，由空格触发（QTE 看不到它）
--
-- 结果是：右键+Shift = 普通闪避；右键+空格 = 瞬身；IA_Dodge 的键位一个都没变。

-- 把每个原生绑定源拆成两份：普通行留在原生动作上，瞬身行搬进私有动作。
-- 绑定源按武器动态增删（换武器会多出 AIM_Mojian_Dash 之类），所以必须每次重读、增量同步。
local function syncSources()
    local list = sourceList()
    if not list then return 0, 0, 0 end
    if not valid(plainAction) then
        plainAction = make('/Script/EnhancedInput.InputAction', 'PlainDodge', dodge)
    end
    if not valid(specialAction) then
        specialAction = make('/Script/EnhancedInput.InputAction', 'SpecialDash', dodge)
    end
    if not plainBindings then plainBindings = {} end
    if not specialBindings then specialBindings = {} end

    local split, healed = 0, 0
    for _, src in ipairs(list) do
        -- 跳过我们自己注册的副本，否则会被当成「原生源」反复处理。
        if not isOurs(src) then
            local k = full(src)
            if not plainBindings[k] then
                if hasSpecialRow(src) then
                    local plain = cloneBinding(src, 'PlainDodge', false)
                    local special = cloneBinding(src, 'SpecialDash', true)
                    pcall(function()
                        component:UnregisterActionInputBindings({ [dodge] = src })
                        component:RegisterActionInputBindings({ [dodge] = plain })
                        component:RegisterActionInputBindings({ [specialAction] = special })
                    end)
                    plainBindings[k] = { source = src, plain = plain }
                    specialBindings[k] = { special = special }
                    split = split + 1
                    log('  拆分源 ' .. k .. '：普通行 -> IA_Dodge，瞬身行 -> 私有动作')
                else
                    -- 这个源本来就没有瞬身行（部分武器/化身没有瞬身）。
                    -- 我们没动过它，卸载时也不能再重复注册一次（会导致该源注册两份）。
                    plainBindings[k] = { source = src, plain = nil, untouched = true }
                end
            elseif hasSpecialRow(src) then
                -- 原生源又出现了（组件被重建/重置过），重新拆一次。
                local rec = plainBindings[k]
                if rec.plain and valid(rec.plain) then
                    pcall(function()
                        component:UnregisterActionInputBindings({ [dodge] = src })
                        component:RegisterActionInputBindings({ [dodge] = rec.plain })
                    end)
                    local sp = specialBindings[k]
                    if sp and valid(sp.special) then
                        pcall(function()
                            component:RegisterActionInputBindings({ [specialAction] = sp.special })
                        end)
                    end
                    healed = healed + 1
                    log('  原生源回来了，已重新拆分 ' .. k)
                end
            end
        end
    end

    if split > 0 or healed > 0 then
        log('源同步: 拆分 ' .. split .. ' / 修回 ' .. healed .. '（当前 ' .. #list .. ' 源）')
    end
    return split, healed
end

local function installShiftGuard()
    if guardInstalled then return true end
    if not valid(dodge) or not valid(component) or not valid(sub) then return false end
    if not keysReleased() then return false end
    local list = sourceList()
    if not list then return false end
    for _, s in ipairs(list) do log('dash source: ' .. full(s)) end

    guardInstalled = true
    local split = syncSources()
    if split == 0 then
        log('WARN: 没有任何绑定源含瞬身行；右键+Shift 可能仍然会瞬身')
    else
        log(SUPPRESS_KEY .. ' 已降级为纯普通闪避（' .. split .. ' 个源被拆分）；'
            .. TRIGGER .. ' 走私有瞬身动作')
    end
    return true
end

local function uninstallShiftGuard()
    if not guardInstalled then return end
    local restored = 0
    if valid(component) and plainBindings then
        for k, rec in pairs(plainBindings) do
            if rec.plain and valid(rec.plain) then
                pcall(function() component:UnregisterActionInputBindings({ [dodge] = rec.plain }) end)
            end
            local sp = specialBindings and specialBindings[k]
            if sp and valid(sp.special) then
                pcall(function() component:UnregisterActionInputBindings({ [specialAction] = sp.special }) end)
            end
            if (not rec.untouched) and rec.source and valid(rec.source) then
                pcall(function() component:RegisterActionInputBindings({ [dodge] = rec.source }) end)
                restored = restored + 1
            end
        end
    end
    guardInstalled = false
    plainBindings, specialBindings = nil, nil
    if not valid(plainAction) then plainAction = nil end
    if not valid(specialAction) then specialAction = nil end
    log('瞬身行已还原回原生动作: ' .. restored .. ' 个源')
end

-- ==================== (1) 右键 + 空格 → 瞬身 ====================

-- MapKey 生成的行没有触发器；不补 Pressed 会按住即每帧触发（连滚）。
local function addPressedMap(ctx, action, keyName, label)
    ctx:MapKey(action, key(keyName))
    local mappings = ctx.DefaultKeyMappings.Mappings
    local count = #mappings
    local pressed = make('/Script/EnhancedInput.InputTriggerPressed', label)
    local hit = false
    each(mappings, function(i, m)
        if i == count then
            local actual = m.Key.KeyName:ToString()
            if not equal(m.Action, action) then log('WARN: appended action mismatch for ' .. keyName) end
            if actual ~= keyName then log('WARN: appended key is ' .. actual .. ', expected ' .. keyName) end
            m.Triggers = { pressed }
            m.Modifiers = {}
            m.bShouldBeIgnored = false
            m.bHasAlwaysTickTrigger = false
            hit = true
        end
    end)
    if not hit then log('WARN: mapping for ' .. keyName .. ' was not appended') end
end

local function ensureSpaceCtx()
    if valid(spaceCtx) then return true end
    local default = StaticFindObject(DEFAULT_CTX)
    if not valid(default) or not valid(dodge) then return false end
    spaceCtx = make('/Script/EnhancedInput.InputMappingContext', 'Ctx')
    -- 跟随默认 gameplay 上下文的输入模式过滤，避免在 UI/菜单里也生效。
    spaceCtx.InputModeFilterOptions = default.InputModeFilterOptions
    spaceCtx.InputModeQueryOverride = default.InputModeQueryOverride
    -- 关键：空格映射到**私有**动作，不再挂到原生 IA_Dodge 上。
    -- 挂到原生动作会让教程 QTE 读到「Shift + 空格」两个键。
    if not valid(specialAction) then
        specialAction = make('/Script/EnhancedInput.InputAction', 'SpecialDash', dodge)
    end
    addPressedMap(spaceCtx, specialAction, TRIGGER, 'SpacePressed')
    local ok, consume = pcall(function() return dodge.bConsumeInput end)
    log('space ctx ready; native bConsumeInput=' .. tostring(ok and consume or '?'))
    return true
end

-- 一次性诊断：dump 当前所有 IMC 里 IA_Dodge 的键位与绑定行，便于核对结果。
-- 注意：IMC 的映射行里没有能力行（那些挂在 InputActionBinding 上），
-- 所以这里读不到 TriggerTag 是正常的，返回空串而不是 '?'。
local function rowTags(row)
    local t = {}
    local ok = pcall(function()
        each(row.NormalData.Actions, function(_, r) t[#t + 1] = r.TriggerTag.TagName:ToString() end)
    end)
    if not ok or #t == 0 then return '' end
    return ' tags=' .. table.concat(t, '|')
end

local function scanContext(c, label)
    pcall(function()
        each(c.DefaultKeyMappings.Mappings, function(_, row)
            if valid(row.Action) and (equal(row.Action, dodge) or equal(row.Action, plainAction)) then
                log('  ' .. label .. ' key=' .. row.Key.KeyName:ToString()
                    .. ' action=' .. (isOurs(row.Action) and 'PLAIN' or 'NATIVE')
                    .. rowTags(row))
            end
        end)
        c.MappingProfileOverrides:ForEach(function(k, p)
            local pr = unwrap(p)
            each(pr.Mappings, function(_, row)
                if valid(row.Action) and (equal(row.Action, dodge) or equal(row.Action, plainAction)) then
                    log('  ' .. label .. ' profile=' .. tostring(k) .. ' key=' .. row.Key.KeyName:ToString()
                        .. ' action=' .. (isOurs(row.Action) and 'PLAIN' or 'NATIVE')
                        .. rowTags(row))
                end
            end)
        end)
    end)
end

local function diagnose()
    if diagnosed then return end
    diagnosed = true
    local ok, err = pcall(function()
        log('--- IA_Dodge 映射诊断 ---')
        for _, set in ipairs(collectRowSets()) do
            log(' ' .. set.label)
            each(set.rows, function(_, row)
                if valid(row.Action) and (equal(row.Action, dodge) or equal(row.Action, plainAction)) then
                    log('   key=' .. row.Key.KeyName:ToString()
                        .. ' action=' .. (isOurs(row.Action) and 'PLAIN' or 'NATIVE')
                        .. rowTags(row))
                end
            end)
        end
        log('--- 诊断结束 ---')
    end)
    if not ok then log('diagnose failed: ' .. tostring(err)) end
end

-- ==================== 挂载 / 卸载 ====================

-- QTE 检测要遍历 QTEManager，是这一帧里最贵的一步。
-- 节流到每 6 帧一次（~100ms），并且只在按住右键要挂载时才查。
local frame = 0
local qteCached, qteAt = false, -100
local function qteActive()
    if frame - qteAt < 6 then return qteCached end
    qteAt = frame
    local ok, found = pcall(function()
        if not valid(pc.QTEManager) then return false end
        local f = false
        pc.QTEManager:ForEach(function(_, v) if valid(unwrap(v)) then f = true end end)
        return f
    end)
    qteCached = (ok and found) or false
    return qteCached
end

local function blockedReason()
    if not valid(pc) then return 'player unavailable' end
    if pc.bShowMouseCursor then return 'cursor visible' end
    if pc:IsMoveInputIgnored() or pc:IsLookInputIgnored() then return 'input reserved' end
    if stats and stats:IsGamePaused(pc) then return 'paused' end
    if qteActive() then return 'qte' end
    return nil
end

local function unmount(opts)
    if mapped and valid(sub) and valid(spaceCtx) then
        pcall(function() sub:RemoveMappingContext(spaceCtx, opts or options) end)
    end
    mapped = false
    -- 只有真的改过才还原，避免每帧都做一次 pcall + 属性比对。
    if consumeDirty and consumeSaved and valid(specialAction) then
        pcall(function()
            if specialAction.bConsumeInput ~= consumeSaved.value then
                specialAction.bConsumeInput = consumeSaved.value
            end
        end)
        consumeDirty = false
    end
end

local function mount()
    if mapped or not valid(spaceCtx) or not valid(sub) then return end
    -- 让私有瞬身动作吃掉空格，否则空格会同时触发跳跃（右键+空格 = 边跳边瞬）。
    -- 注意不要再动原生 IA_Dodge 的 consume：QTE 会读它。
    if valid(specialAction) then
        pcall(function()
            if not consumeSaved then consumeSaved = { value = specialAction.bConsumeInput == true } end
            if specialAction.bConsumeInput ~= true then
                specialAction.bConsumeInput = true
                consumeDirty = true
            end
        end)
    end
    sub:AddMappingContext(spaceCtx, PRIORITY, options)
    mapped = true
end

local function cleanup(opts)
    unmount(opts)
    uninstallShiftGuard()
    spaceCtx, component, sub = nil, nil, nil
    componentAddr = nil
end

-- 切图 / 重生 / 读档瞬间的"轻量收尾"：只摘自己挂的 IMC、丢引用，
-- 不做任何"遍历映射行 / 读 PlayerInput"的动作。
-- 原因：那一刻旧 PlayerController、IMC、输入组件正在销毁，读它们的属性会让
-- UE4SS 在 native 属性绑定器里崩（0xC0000005，pcall 抓不住）。
-- 映射行本来就指向本 mod 的私有动作，保留下来，下一次接管时直接复用。
local function dropSession(reason)
    pcall(function() unmount({ bForceImmediately = true, bNotifyUserSettings = false }) end)
    mapped = false
    component, sub, componentAddr = nil, nil, nil
    guardInstalled = false
    plainBindings, specialBindings = nil, nil
    if reason then log('会话结束: ' .. reason) end
end

-- 换图 / 死亡重生 / 换 Pawn 都会换一份 AbilityInputComponent。
-- 私有动作的绑定是挂在旧组件上的，新组件里没有它，Shift 就查不到可用行 → 闪避失灵，
-- 而 Space 走原生 IA_Dodge 所以一直正常。这里用组件地址做身份，一换就整体重建。
local function resetGuard(reason)
    if guardInstalled or plainBindings then log('重置瞬身接管: ' .. reason) end
    if valid(component) and plainBindings then
        for k, rec in pairs(plainBindings) do
            if rec.plain and valid(rec.plain) then
                pcall(function() component:UnregisterActionInputBindings({ [dodge] = rec.plain }) end)
            end
            local sp = specialBindings and specialBindings[k]
            if sp and valid(sp.special) then
                pcall(function() component:UnregisterActionInputBindings({ [specialAction] = sp.special }) end)
            end
        end
    end
    guardInstalled = false
    plainBindings, specialBindings = nil, nil
    retargets = 0
    componentAddr = nil
end

local function componentChanged()
    if not valid(component) then return false end
    local ok, addr = pcall(function() return component:GetAddress() end)
    if not ok or addr == nil then return false end
    if componentAddr == nil then componentAddr = addr; return false end
    if addr ~= componentAddr then
        componentAddr = addr
        return true
    end
    return false
end

-- 静默自检：只在「私有绑定掉了」或「没有行接管到私有动作」时留痕。
-- 这是给以后失灵时定位用的——健康时不输出任何东西。
local function healthCheck()
    if not (valid(component) and valid(specialAction)) then
        log('WARN 健康检查: 组件或私有瞬身动作已失效')
        return
    end
    local hasPrivate = bindingCount(specialAction) > 0
    -- 扫一遍原生源：还有含瞬身行的源没被拆，说明右键+Shift 会漏出瞬身。
    local leaked = 0
    local list = sourceList()
    if list then
        for _, src in ipairs(list) do
            if (not isOurs(src)) and hasSpecialRow(src) then leaked = leaked + 1 end
        end
    end
    if (not hasPrivate) or leaked > 0 then
        log('WARN 健康检查: 私有瞬身绑定=' .. tostring(hasPrivate)
            .. ' 未拆分的原生源=' .. leaked .. '（瞬身可能失灵或漏出）')
    end
end

-- 热路径：只在状态真的变化时才碰引擎。
local function run()
    if not ensureRefs() then
        -- 组件地址没变、但原生动作绑定不见了：说明这个组件被重置过（换图/复活/
        -- 离开战斗都会）。丢掉它，下一帧从 Pawn 重新取一份并重建私有绑定，
        -- 否则会永久停在「按什么都没反应」的状态。
        if refBlock == 'IA_Dodge 未注册到组件' and valid(component) then
            component, sub, componentAddr = nil, nil, nil
            guardInstalled = false
            plainBindings, specialBindings = nil, nil
            if frame % 600 == 0 then log('组件绑定丢失，已丢弃并重建接管') end
        end
        return
    end
    -- 私有动作被销毁（换图/组件重建）时，空格上下文里留着的是死引用 ——
    -- 不一起重建的话，右键+空格会彻底没反应。
    if valid(spaceCtx) and not valid(specialAction) then
        if mapped and valid(sub) then
            pcall(function() sub:RemoveMappingContext(spaceCtx, options) end)
        end
        mapped, spaceCtx = false, nil
    end
    if not valid(spaceCtx) then if not ensureSpaceCtx() then return end end

    if componentChanged() then resetGuard('输入组件已更换') end

    if not guardInstalled then
        installShiftGuard()
    elseif frame % 6 == 0 then
        -- 换武器会动态增删 dash 绑定源；每 6 帧跟着增量同步一次。
        -- 这里**不调用 RequestRebuildControlMappings**：换绑定内容本身即时生效，
        -- 而重建会让游戏把原生源（含瞬身行）重新灌回来 —— 那正是旧版 1Hz 抖动的来源。
        syncSources()
        -- 每 10 秒静默自检：只在不健康时留日志，方便下次失灵时直接定位。
        if frame % 600 == 0 then healthCheck() end
    end

    -- 没按右键时直接退出：QTE 遍历、菜单状态查询全部跳过。
    if not pc:IsInputKeyDown(K_MODIFIER) then
        unmount()
        return
    end
    if blockedReason() then
        unmount()
        return
    end
    mount()
    diagnose()
end

local function step()
    -- 1) 已有玩家：纯地址比较，不调用 GetFullName、不生成任何字符串。
    if valid(pc) and valid(pawn) then
        local ok, current = pcall(function() return pc.Pawn end)
        if ok and valid(current) and equal(current, pawn) then
            return run()
        end
        -- 玩家消失或换人（重生、换图、读档）：
        -- 只摘掉自己挂的 IMC 再丢引用，**绝不**在这里遍历映射行 —— 旧 PlayerInput /
        -- IMC 正在销毁，读属性会让 UE4SS 在 native 属性绑定器上直接崩，pcall 抓不住。
        dropSession('换人/换图')
        pc, pawn, pawnFull = nil, nil, nil
        return
    end

    -- 2) 没有玩家：每 15 帧找一次（启动时 frame==1 立即找）。
    if frame % 15 ~= 1 then return end
    local c, p, name = currentPlayer()
    if not c then
        if mapped or guardInstalled then dropSession('无玩家') end
        return
    end
    if pc ~= nil then
        -- 旧控制器/旧 Pawn 已失效（换图、读档、重生都会这样）。
        -- 上一份会话的私有绑定不能再复用，全部作废，等下面重建。
        resetGuard('重新获取玩家')
        component, sub = nil, nil
        pc, pawn = nil, nil
    end
    pc, pawn, pawnFull = c, p, name
    log('local player: ' .. tostring(name))
    run()
end

-- 未接管成功时每 10 秒打一条完整状态。
-- 目标是让「日志里什么都没有」这种事不再发生：任何一次失灵都能直接看出卡在哪一步。
local function heartbeat()
    local same = false
    pcall(function() same = valid(pc) and valid(pawn) and equal(pc.Pawn, pawn) end)
    -- 单独探一次「能不能找到玩家」，用来区分「玩家还没生成」和「找到了但引用步骤失败」。
    local okFind, fc = pcall(currentPlayer)
    local find = (okFind and valid(fc)) and 'yes' or 'no'
    -- 把当前 Pawn 的蓝图名一并打出来：换角色时一眼就能看出是不是认错了对象。
    local pn = '-'
    pcall(function()
        if valid(pawn) then
            local n = pawn:GetFullName()
            pn = n:match('PersistentLevel%.([%w_]+)') or n
        end
    end)
    log('状态 frame=' .. frame
        .. ' worldLoading=' .. tostring(worldLoading)
        .. ' holdLeft=' .. tostring(holdUntil - frame)
        .. ' pc=' .. tostring(valid(pc))
        .. ' pawn=' .. tostring(valid(pawn))
        .. ' pawnName=' .. pn
        .. ' samePawn=' .. tostring(same)
        .. ' find=' .. find
        .. ' comp=' .. tostring(valid(component))
        .. ' sub=' .. tostring(valid(sub))
        .. ' ctx=' .. tostring(valid(spaceCtx))
        .. ' guard=' .. tostring(guardInstalled)
        .. ' refs=' .. tostring(refBlock))
end

-- 单次异常不当致命：切图/读档的瞬间本来就会出现短暂的非法状态。
-- 只有连续 5 次都恢复不了才真正停手，并且明确告知"重启游戏即可恢复"。
local fails = 0
local function tick()
    if stopped then return end
    frame = frame + 1

    -- 切图窗口：一步都不碰引擎。这是本次崩溃（UE4SS.dll+0x22FC8D）的直接防线。
    if worldLoading or frame < holdUntil then
        if frame % 600 == 0 then log('切图静默中，剩余 ' .. (holdUntil - frame) .. ' 帧') end
        return
    end

    if frame % 600 == 0 and not guardInstalled then heartbeat() end

    local ok, err = pcall(step)
    if ok then
        if fails > 0 then log('已恢复正常（此前异常 ' .. fails .. ' 次）') end
        fails = 0
        return
    end
    fails = fails + 1
    log('WARN 第 ' .. fails .. ' 次异常: ' .. tostring(err))
    -- 第一次和每第 3 次尝试回滚，避免每帧重建映射
    if fails == 1 or fails % 3 == 0 then
        local restored = pcall(function() cleanup({ bForceImmediately = true, bNotifyUserSettings = false }) end)
        if not restored then log('WARN 回滚未完成，若 Shift 闪不出来请重启游戏') end
    end
    if fails >= 5 then
        stopped = true
        log('DISABLED: 连续 5 次异常，已停止接管。重启游戏即可恢复原版映射。')
    end
end

if ModRef then
    ModRef.OnUnload = function()
        stopped = true
        pcall(function()
            ExecuteInGameThread(function()
                pcall(function() cleanup({ bForceImmediately = true, bNotifyUserSettings = false }) end)
            end)
        end)
    end
end

-- 切图事件驱动：进入切图先安全收尾并停手，落地后再等约 4 秒恢复。
-- 这两个钩子在 UE4SS 3.0 起提供；拿不到就靠 step() 的换人检测兜底。
local okPre = pcall(RegisterLoadMapPreHook, function()
    worldLoading = true
    holdUntil = frame + 3600      -- 兜底：万一 Post 没来也不会永久卡死
    dropSession('切图')
    log('切图开始：暂停接管')
end)
local okPost = pcall(RegisterLoadMapPostHook, function()
    worldLoading = false
    holdUntil = frame + 240       -- ≈4 秒，避开对象销毁/生成高峰
    log('切图结束：约 4 秒后恢复接管')
end)
if not okPre then log('WARN: RegisterLoadMapPreHook 不可用，靠换人检测兜底') end
if not okPost then log('WARN: RegisterLoadMapPostHook 不可用，靠换人检测兜底') end

local started, err = pcall(LoopInGameThreadWithDelay, 1, tick)
if not started then log('DISABLED: ' .. tostring(err)); return end
log('v0.4.0 loaded; ' .. MODIFIER .. '+' .. TRIGGER .. ' -> 瞬身; ' .. MODIFIER .. '+LeftShift -> 普通闪避. Waiting for player.')
