-- PBZFlashStepSpace 0.3.1 | Steam build CL-301524 / UE 5.7.4
--
-- 只做两件事，其它一概不动：
--   (1) 新增  右键 + 空格   → 瞬身
--   (2) 禁用  右键 + 左Shift → 瞬身（左Shift 只剩普通闪避那套行）
--
-- 依据（本 build 已实测的输入结构，来自 318 的源码）：
--   瞬身与普通闪避共用同一个原生动作 /PBZDeflectSystem/Input/IA_Dodge，
--   区别只在该动作绑定行的 TriggerTag：
--     · 普通闪避 = TriggerTag 不等于 Ability.Action.Hun.SpecialDash
--     · 瞬身     = TriggerTag 等于 Ability.Action.Hun.SpecialDash（并要求按住右键的架势 tag）
--   IA_Dodge 的键盘映射行位于 IMC_Deflect：318 在键盘配置下用
--   assert(replaced>0) 强制要求改到这一行，否则直接报错，所以这一点可确定。
--
-- 做法：
--   (2) 把 IMC 里「IA_Dodge + LeftShift」的映射行改指向一份私有副本，
--       该副本只携带“非瞬身行”。于是 Shift 依旧能普通闪避，但永远选不到瞬身行。
--       原映射行本身没被删除，只换了 Action 引用，随时可还原。
--   (1) 自建 InputMappingContext（优先级 100），把 SpaceBar 映射到原生 IA_Dodge，
--       并且只在按住右键时挂载 —— 空格平时仍然是跳跃。
--   不删技能、不改数值/存档、不碰 K2_CanActivateAbility、不动其它按键。
local MOD = 'PBZFlashStepSpace'
local TRIGGER = 'SpaceBar'
local MODIFIER = 'RightMouseButton'
local SUPPRESS_KEY = 'LeftShift' -- 要移除瞬身语义的物理键（默认键位）
local PRIORITY = 100
local DEVICE_ID = 1 -- 键盘鼠标
local DODGE_PATH = '/PBZDeflectSystem/Input/IA_Dodge.IA_Dodge'
local DEFLECT_CTX = '/PBZInput/IMC_Deflect.IMC_Deflect'
local DEFAULT_CTX = '/PBZInput/IMC_Default.IMC_Default'
local BASE_BINDING = '/PBZCombatAsset/ActorData/Players/Hun/InputMap/AIM_Hun_Dash.AIM_Hun_Dash'
local SPECIAL = 'Ability.Action.Hun.SpecialDash'

local function log(s) print('[' .. MOD .. '] ' .. s .. '\n') end
if type(LoopInGameThreadWithDelay) ~= 'function' then
    log('DISABLED: game-thread timer unavailable')
    return
end

local function valid(o) return o ~= nil and o:IsValid() end
local function equal(a, b) return valid(a) and valid(b) and a:GetAddress() == b:GetAddress() end
local function unwrap(v) local ok, x = pcall(function() return v:get() end); return ok and x or v end
local function key(name) return { KeyName = FName(name) } end
local function full(o) local n = o:GetFullName(); return n:match('^%S+ (.+)$') or n end
local function each(a, fn)
    if a == nil then return end
    if type(a) == 'table' and type(a.ForEach) ~= 'function' then
        for i, v in ipairs(a) do fn(i, v) end
    else
        a:ForEach(function(i, v) fn(i, unwrap(v)) end)
    end
end
-- 按名字识别本 mod 造的私有动作。换人/换组件后旧对象可能已失效，
-- 但 IMC 行里还留着它的引用，靠名字才能把它们捞回来重定向。
local function isOurs(action)
    if not action then return false end
    local ok, name = pcall(function() return action:GetFullName() end)
    if not ok or type(name) ~= 'string' then return false end
    return name:find('PBZFS_PlainDodge_', 1, true) ~= nil
end

local function array(a)
    local r = {}
    each(a, function(_, v) if v ~= nil then r[#r + 1] = v end end)
    return r
end

-- 帧循环里反复用到的 FKey 预先构造好：FName 走全局名字表，
-- 每帧新建一次是纯浪费，这里只建一次。
local K_MODIFIER = { KeyName = FName(MODIFIER) }
local K_TRIGGER = { KeyName = FName(TRIGGER) }
local K_SUPPRESS = { KeyName = FName(SUPPRESS_KEY) }

local options = { bIgnoreAllPressedKeysUntilRelease = true, bForceImmediately = true, bNotifyUserSettings = false }
local pc, pawn, pawnFull, component, sub, stats, dodge, outer, serial
local spaceCtx, plainAction, plainBindings
local mapped, stopped, diagnosed = false, false, false
local guardInstalled = false
local retargets = 0
local componentAddr   -- 当前接管所依附的 InputComponent 身份，用来发现组件被换掉
local consumeSaved, consumeDirty

local function make(class, label, template)
    local cl = StaticFindObject(class)
    assert(valid(cl), 'Missing class ' .. class)
    serial = (serial or 0) + 1
    local o = StaticConstructObject(cl, outer, FName('PBZFS_' .. label .. '_' .. serial, EFindName.FNAME_Add),
        0x40, 0x40000000, false, false, template)
    assert(valid(o), 'Cannot construct ' .. label)
    return o
end

local function playerFrom(c)
    local ok, p, name = pcall(function()
        if not valid(c) or not c:IsLocalController() then return end
        local p = c.Pawn
        if not valid(p) then return end
        local n = p:GetFullName()
        if n:find('PersistentLevel.BP_Renewal_Hun_C_', 1, true) then return p, n end
    end)
    if ok and p then return c, p, name end
end

local function currentPlayer()
    local c, p, name = playerFrom(pc)
    if c then return c, p, name end
    for _, candidate in ipairs(FindAllOf('PlayerController') or {}) do
        c, p, name = playerFrom(candidate)
        if c then return c, p, name end
    end
end

local function findSub()
    for _, s in ipairs(FindAllOf('EnhancedInputLocalPlayerSubsystem') or {}) do
        if valid(s) and equal(s:GetOuter(), pc.Player) then return s end
    end
end

local function ensureRefs()
    if not (valid(pc) and valid(pawn)) then return false end
    if not valid(stats) then
        stats = StaticFindObject('/Script/Engine.Default__GameplayStatics')
        if not valid(stats) then return false end
    end
    if not valid(dodge) then
        dodge = StaticFindObject(DODGE_PATH)
        if not valid(dodge) then return false end
    end
    if not valid(outer) then
        outer = pc.Player
        if not valid(outer) then return false end
    end
    if not valid(component) then
        component = pawn:GetAbilityInputComponent()
        if not valid(component) then return false end
    end
    if not valid(sub) then
        sub = findSub()
        if not valid(sub) then return false end
    end
    -- 原生动作还没注册到能力输入组件上，说明还没进可操作状态。
    if not component.InputBindings:Contains(dodge) then return false end
    return true
end

-- ==================== (2) 让左Shift不再触发瞬身 ====================

-- 只保留非瞬身行。读不出 TriggerTag 的行一律保留：宁可多留，不可误删。
-- fallback：条件桶里一条普通行都不剩时，用 NormalData 的普通行补上。
--   原因：瞬身行挂在「按住右键」的条件桶里。若该桶原本只有瞬身行，
--   摘掉后桶就空了，按住右键反而变得什么都按不出来 —— 那不是"禁用瞬身"，
--   而是把闪避一起弄坏了。补上后：右键+Shift 稳定退回普通闪避。
local function filterRows(data, keepSpecial, fallback)
    local left = 0
    for _, field in ipairs({ 'Actions', 'Combos', 'InterruptLower' }) do
        local kept = {}
        each(data[field], function(_, row)
            local ok, tag = pcall(function() return row.TriggerTag.TagName:ToString() end)
            local isSpecial = ok and tag == SPECIAL
            if isSpecial == keepSpecial then kept[#kept + 1] = row end
        end)
        data[field] = kept
        left = left + #kept
    end
    if left == 0 and fallback then
        for _, field in ipairs({ 'Actions', 'Combos', 'InterruptLower' }) do
            data[field] = array(fallback[field])
        end
        return 'filled'
    end
end

local function cloneBinding(source, label)
    local copy = make('/Script/SGameInputSystem.InputActionBinding', label, source)
    each(copy.Bindings, function(_, entry)
        filterRows(entry.NormalData, false, nil)
        entry.TagConditionData:ForEach(function(k, v)
            local how = filterRows(unwrap(v), false, entry.NormalData)
            if how == 'filled' then
                local ok, name = pcall(function() return unwrap(k).TagName:ToString() end)
                log('  条件桶 ' .. tostring(ok and name or k) .. ' 已无普通行，用普通行补上（保持按住右键可闪避）')
            end
        end)
    end)
    return copy
end

-- 枚举可能存放 IA_Dodge 映射行的容器：当前生效的上下文 + 两个关键 IMC 资产；
-- 每个容器再展开 MappingProfileOverrides（游戏内键位档案就存在这里）。
local function collectRowSets()
    local sets, seen = {}, {}
    local function addContext(c, label)
        if not valid(c) or seen[c:GetAddress()] then return end
        seen[c:GetAddress()] = true
        sets[#sets + 1] = { rows = c.DefaultKeyMappings.Mappings, label = label .. ' default' }
        pcall(function()
            c.MappingProfileOverrides:ForEach(function(k, p)
                local pr = unwrap(p)
                if valid(pr) then
                    sets[#sets + 1] = { rows = pr.Mappings, label = label .. ' profile=' .. tostring(k) }
                end
            end)
        end)
    end
    local applied = 0
    local function collect(field)
        local good, map = pcall(function() return pc.PlayerInput[field] end)
        if good and map then
            map:ForEach(function(k)
                local c = unwrap(k)
                if valid(c) and not equal(c, spaceCtx) then applied = applied + 1; addContext(c, full(c)) end
            end)
        end
    end
    collect('AppliedInputContextData')
    if applied == 0 then collect('AppliedInputContexts') end
    for _, path in ipairs({ DEFLECT_CTX, DEFAULT_CTX }) do
        local c = StaticFindObject(path)
        if valid(c) then addContext(c, full(c)) end
    end
    return sets
end

-- 重建玩家映射。必须等按键全部松开再做：重建会刷掉原生 Pressed 触发器，
-- 若此时按键正被按住，一次物理按下会被算成两次。318 的源码里专门为此写了注释。
local function rebuild()
    if not valid(sub) then return false end
    local ok = pcall(function() sub:RequestRebuildControlMappings(options, DEVICE_ID) end)
    if not ok then log('WARN: RequestRebuildControlMappings failed') end
    return ok
end

local function keysReleased()
    for _, k in ipairs({ K_MODIFIER, K_TRIGGER, K_SUPPRESS }) do
        local ok, down = pcall(function() return pc:IsInputKeyDown(k) end)
        if not ok or down then return false end
    end
    return true
end

-- 读原生 IA_Dodge 当前挂着的绑定源。
-- 关键：游戏会按武器动态增删这些源（魔剑有 AIM_Mojian_Dash，别的武器还有各自的），
-- 所以任何时刻都必须重新读，不能装完一次就缓存住。
local function sourceList()
    if not (valid(component) and valid(dodge)) then return nil end
    if not component.InputBindings:Contains(dodge) then return nil end
    local list = array(component.InputBindings:Find(dodge):get().Bindings)
    if #list == 0 then return nil end
    return list
end

-- 把 plainAction 的绑定源同步成「和原生一模一样」。
-- 这是 Shift 闪避失灵的直接修复：换武器后新源进来、旧源走掉，这里跟着补/撤。
local function syncPlain()
    local list = sourceList()
    if not list then return 0, 0 end
    if not valid(plainAction) then
        plainAction = make('/Script/EnhancedInput.InputAction', 'PlainDodge', dodge)
    end
    -- plainAction 会跨换人复用，但绑定表每次重新建立，所以两者必须分开判空。
    if not plainBindings then plainBindings = {} end
    local seen, added, removed = {}, 0, 0
    for _, s in ipairs(list) do
        local k = s:GetAddress() .. '|' .. full(s)
        seen[k] = true
        if not plainBindings[k] then
            local b = cloneBinding(s, 'PlainDodgeBind')
            component:RegisterActionInputBindings({ [plainAction] = b })
            plainBindings[k] = { source = s, binding = b }
            added = added + 1
        end
    end
    for k, rec in pairs(plainBindings) do
        if not seen[k] then
            if valid(rec.binding) then
                pcall(function() component:UnregisterActionInputBindings({ [plainAction] = rec.binding }) end)
            end
            plainBindings[k] = nil
            removed = removed + 1
        end
    end
    -- 组件整体重建时，挂在它上面的自定义绑定会被一起清掉，这里补挂。
    if #list > 0 and not component.InputBindings:Contains(plainAction) then
        local n = 0
        for _, rec in pairs(plainBindings) do
            if valid(rec.binding) then
                pcall(function() component:RegisterActionInputBindings({ [plainAction] = rec.binding }) end)
                n = n + 1
            end
        end
        log('plain 绑定被组件重置，已重新挂载 ' .. n .. ' 个源')
    end
    if added > 0 or removed > 0 then
        log('plain 源同步: +' .. added .. ' / -' .. removed .. ' (当前 ' .. #list .. ')')
    end
    return added, removed
end

-- 把「还指向原生 IA_Dodge」的 LeftShift 行接管到 plainAction 上。
-- 新武器/新上下文可能带来新的这样一行，所以要能重复执行。返回接管数量。
local function retargetPending()
    local rows = {}
    for _, set in ipairs(collectRowSets()) do
        each(set.rows, function(_, row)
            pcall(function()
                local live = valid(row.Action)
                local mine = live and (equal(row.Action, dodge) or isOurs(row.Action))
                -- Action 已经失效：说明这一行指向被销毁的旧私有动作，
                -- 不修的话它永远匹配不到任何能力，即「Shift 彻底按不出来」。
                local dead = not live
                if (mine or dead) and row.Key.KeyName:ToString() == SUPPRESS_KEY then
                    rows[#rows + 1] = row
                    log('  retarget ' .. set.label .. ' key=' .. SUPPRESS_KEY .. (dead and ' (旧动作已失效)' or ''))
                end
            end)
        end)
    end
    if #rows == 0 then return 0 end
    for _, row in ipairs(rows) do pcall(function() row.Action = plainAction end) end
    rebuild()
    return #rows
end

local function installShiftGuard()
    if guardInstalled then return true end
    if not valid(dodge) or not valid(component) or not valid(sub) then return false end
    if not keysReleased() then return false end
    local list = sourceList()
    if not list then return false end
    for _, s in ipairs(list) do log('dash source: ' .. full(s)) end

    syncPlain()
    guardInstalled = true
    local n = retargetPending()
    if n > 0 then
        log(SUPPRESS_KEY .. ' 已改为只走普通闪避行: ' .. n .. ' 处映射')
    else
        log('WARN: 没找到 ' .. SUPPRESS_KEY .. ' -> IA_Dodge 的映射行；该键的瞬身可能仍然存在')
    end
    return true
end

local function uninstallShiftGuard()
    if not guardInstalled then return end
    local restored = 0
    if valid(plainAction) then
        for _, set in ipairs(collectRowSets()) do
            each(set.rows, function(_, row)
                pcall(function()
                    if isOurs(row.Action) then
                        row.Action = dodge; restored = restored + 1
                    end
                end)
            end)
        end
    end
    if valid(component) and valid(plainAction) and plainBindings then
        for _, rec in pairs(plainBindings) do
            if valid(rec.binding) then
                pcall(function() component:UnregisterActionInputBindings({ [plainAction] = rec.binding }) end)
            end
        end
    end
    guardInstalled = false
    plainBindings = nil
    if not valid(plainAction) then plainAction = nil end
    rebuild()
    log(SUPPRESS_KEY .. ' 映射已还原: ' .. restored .. ' 处')
end

-- ==================== (1) 右键 + 空格 → 瞬身 ====================

-- MapKey 生成的行没有触发器；不补 Pressed 会按住即每帧触发（连滚）。
local function addPressedMap(ctx, action, keyName, label)
    ctx:MapKey(action, key(keyName))
    local mappings = ctx.DefaultKeyMappings.Mappings
    local count = #mappings
    local pressed = make('/Script/EnhancedInput.InputTriggerPressed', label)
    local hit = false
    each(mappings, function(i, m)
        if i == count then
            local actual = m.Key.KeyName:ToString()
            if not equal(m.Action, action) then log('WARN: appended action mismatch for ' .. keyName) end
            if actual ~= keyName then log('WARN: appended key is ' .. actual .. ', expected ' .. keyName) end
            m.Triggers = { pressed }
            m.Modifiers = {}
            m.bShouldBeIgnored = false
            m.bHasAlwaysTickTrigger = false
            hit = true
        end
    end)
    if not hit then log('WARN: mapping for ' .. keyName .. ' was not appended') end
end

local function ensureSpaceCtx()
    if valid(spaceCtx) then return true end
    local default = StaticFindObject(DEFAULT_CTX)
    if not valid(default) or not valid(dodge) then return false end
    spaceCtx = make('/Script/EnhancedInput.InputMappingContext', 'Ctx')
    -- 跟随默认 gameplay 上下文的输入模式过滤，避免在 UI/菜单里也生效。
    spaceCtx.InputModeFilterOptions = default.InputModeFilterOptions
    spaceCtx.InputModeQueryOverride = default.InputModeQueryOverride
    addPressedMap(spaceCtx, dodge, TRIGGER, 'SpacePressed')
    local ok, consume = pcall(function() return dodge.bConsumeInput end)
    log('space ctx ready; native bConsumeInput=' .. tostring(ok and consume or '?'))
    return true
end

-- 一次性诊断：dump 当前所有 IMC 里 IA_Dodge 的键位与绑定行，便于核对结果。
-- 注意：IMC 的映射行里没有能力行（那些挂在 InputActionBinding 上），
-- 所以这里读不到 TriggerTag 是正常的，返回空串而不是 '?'。
local function rowTags(row)
    local t = {}
    local ok = pcall(function()
        each(row.NormalData.Actions, function(_, r) t[#t + 1] = r.TriggerTag.TagName:ToString() end)
    end)
    if not ok or #t == 0 then return '' end
    return ' tags=' .. table.concat(t, '|')
end

local function scanContext(c, label)
    pcall(function()
        each(c.DefaultKeyMappings.Mappings, function(_, row)
            if valid(row.Action) and (equal(row.Action, dodge) or equal(row.Action, plainAction)) then
                log('  ' .. label .. ' key=' .. row.Key.KeyName:ToString()
                    .. ' action=' .. (isOurs(row.Action) and 'PLAIN' or 'NATIVE')
                    .. rowTags(row))
            end
        end)
        c.MappingProfileOverrides:ForEach(function(k, p)
            local pr = unwrap(p)
            each(pr.Mappings, function(_, row)
                if valid(row.Action) and (equal(row.Action, dodge) or equal(row.Action, plainAction)) then
                    log('  ' .. label .. ' profile=' .. tostring(k) .. ' key=' .. row.Key.KeyName:ToString()
                        .. ' action=' .. (isOurs(row.Action) and 'PLAIN' or 'NATIVE')
                        .. rowTags(row))
                end
            end)
        end)
    end)
end

local function diagnose()
    if diagnosed then return end
    diagnosed = true
    local ok, err = pcall(function()
        log('--- IA_Dodge 映射诊断 ---')
        for _, set in ipairs(collectRowSets()) do
            log(' ' .. set.label)
            each(set.rows, function(_, row)
                if valid(row.Action) and (equal(row.Action, dodge) or equal(row.Action, plainAction)) then
                    log('   key=' .. row.Key.KeyName:ToString()
                        .. ' action=' .. (isOurs(row.Action) and 'PLAIN' or 'NATIVE')
                        .. rowTags(row))
                end
            end)
        end
        log('--- 诊断结束 ---')
    end)
    if not ok then log('diagnose failed: ' .. tostring(err)) end
end

-- ==================== 挂载 / 卸载 ====================

-- QTE 检测要遍历 QTEManager，是这一帧里最贵的一步。
-- 节流到每 6 帧一次（~100ms），并且只在按住右键要挂载时才查。
local frame = 0
local qteCached, qteAt = false, -100
local function qteActive()
    if frame - qteAt < 6 then return qteCached end
    qteAt = frame
    local ok, found = pcall(function()
        if not valid(pc.QTEManager) then return false end
        local f = false
        pc.QTEManager:ForEach(function(_, v) if valid(unwrap(v)) then f = true end end)
        return f
    end)
    qteCached = (ok and found) or false
    return qteCached
end

local function blockedReason()
    if not valid(pc) then return 'player unavailable' end
    if pc.bShowMouseCursor then return 'cursor visible' end
    if pc:IsMoveInputIgnored() or pc:IsLookInputIgnored() then return 'input reserved' end
    if stats and stats:IsGamePaused(pc) then return 'paused' end
    if qteActive() then return 'qte' end
    return nil
end

local function unmount(opts)
    if mapped and valid(sub) and valid(spaceCtx) then
        pcall(function() sub:RemoveMappingContext(spaceCtx, opts or options) end)
    end
    mapped = false
    -- 只有真的改过才还原，避免每帧都做一次 pcall + 属性比对。
    if consumeDirty and consumeSaved and valid(dodge) then
        pcall(function()
            if dodge.bConsumeInput ~= consumeSaved.value then dodge.bConsumeInput = consumeSaved.value end
        end)
        consumeDirty = false
    end
end

local function mount()
    if mapped or not valid(spaceCtx) or not valid(sub) then return end
    if valid(dodge) then
        pcall(function()
            if not consumeSaved then consumeSaved = { value = dodge.bConsumeInput == true } end
            if dodge.bConsumeInput ~= true then dodge.bConsumeInput = true; consumeDirty = true end
        end)
    end
    sub:AddMappingContext(spaceCtx, PRIORITY, options)
    mapped = true
end

local function cleanup(opts)
    unmount(opts)
    uninstallShiftGuard()
    spaceCtx, component, sub = nil, nil, nil
    componentAddr = nil
end

-- 换图 / 死亡重生 / 换 Pawn 都会换一份 AbilityInputComponent。
-- 私有动作的绑定是挂在旧组件上的，新组件里没有它，Shift 就查不到可用行 → 闪避失灵，
-- 而 Space 走原生 IA_Dodge 所以一直正常。这里用组件地址做身份，一换就整体重建。
local function resetGuard(reason)
    if guardInstalled or plainBindings then log('重置 Shift 接管: ' .. reason) end
    if valid(component) and valid(plainAction) and plainBindings then
        for _, rec in pairs(plainBindings) do
            if valid(rec.binding) then
                pcall(function() component:UnregisterActionInputBindings({ [plainAction] = rec.binding }) end)
            end
        end
    end
    guardInstalled = false
    plainBindings = nil
    retargets = 0
    componentAddr = nil
end

local function componentChanged()
    if not valid(component) then return false end
    local ok, addr = pcall(function() return component:GetAddress() end)
    if not ok or addr == nil then return false end
    if componentAddr == nil then componentAddr = addr; return false end
    if addr ~= componentAddr then
        componentAddr = addr
        return true
    end
    return false
end

-- 静默自检：只在「私有绑定掉了」或「没有行接管到私有动作」时留痕。
-- 这是给以后失灵时定位用的——健康时不输出任何东西。
local function healthCheck()
    if not (valid(component) and valid(plainAction)) then
        log('WARN 健康检查: 组件或私有动作已失效')
        return
    end
    local hasBinding = false
    pcall(function() hasBinding = component.InputBindings:Contains(plainAction) end)
    local rows = 0
    for _, set in ipairs(collectRowSets()) do
        each(set.rows, function(_, row)
            pcall(function()
                if isOurs(row.Action) and row.Key.KeyName:ToString() == SUPPRESS_KEY then rows = rows + 1 end
            end)
        end)
    end
    if not hasBinding or rows == 0 then
        log('WARN 健康检查: 私有绑定=' .. tostring(hasBinding) .. ' 接管行=' .. rows .. '（Shift 可能失灵）')
    end
end

-- 热路径：只在状态真的变化时才碰引擎。
local function run()
    if not ensureRefs() then return end
    if not valid(spaceCtx) then if not ensureSpaceCtx() then return end end

    if componentChanged() then resetGuard('输入组件已更换') end

    if not guardInstalled then
        installShiftGuard()
    elseif frame % 6 == 0 then
        -- 换武器会动态增删 dash 源；Shift 指向的正是这些源的副本，必须跟着走，
        -- 否则新武器的闪避行不在副本里，Shift 就会「失灵」。
        syncPlain()
        if frame % 60 == 0 and keysReleased() then
            local n = retargetPending()
            if n > 0 then
                retargets = retargets + 1
                -- 只记前 8 次避免刷屏，但接管本身不设上限：
                -- 游戏反复重建映射行时若中途放弃，Shift 会永久留在失灵状态。
                if retargets <= 8 then
                    log('重新接管 ' .. n .. ' 处 ' .. SUPPRESS_KEY .. ' 映射（第 ' .. retargets .. ' 次）')
                end
            end
        end
        -- 每 10 秒静默自检：只在不健康时留日志，方便下次失灵时直接定位。
        if frame % 600 == 0 then healthCheck() end
    end

    -- 没按右键时直接退出：QTE 遍历、菜单状态查询全部跳过。
    if not pc:IsInputKeyDown(K_MODIFIER) then
        unmount()
        return
    end
    if blockedReason() then
        unmount()
        return
    end
    mount()
    diagnose()
end

local function step()
    frame = frame + 1

    -- 1) 已有玩家：纯地址比较，不调用 GetFullName、不生成任何字符串。
    if valid(pc) and valid(pawn) then
        local ok, current = pcall(function() return pc.Pawn end)
        if ok and valid(current) and equal(current, pawn) then
            return run()
        end
        -- 玩家消失或换人：立刻卸载，别等到下一轮扫描。
        cleanup()
        pc, pawn, pawnFull = nil, nil, nil
        return
    end

    -- 2) 没有玩家：每 15 帧找一次（启动时 frame==1 立即找）。
    if frame % 15 ~= 1 then return end
    local c, p, name = currentPlayer()
    if not c then
        if mapped or valid(spaceCtx) or guardInstalled then cleanup() end
        return
    end
    if pc ~= nil then
        -- 旧控制器/旧 Pawn 已失效（换图、读档、重生都会这样）。
        -- 上一份会话的私有绑定不能再复用，全部作废，等下面重建。
        resetGuard('重新获取玩家')
        component, sub = nil, nil
        pc, pawn = nil, nil
    end
    pc, pawn, pawnFull = c, p, name
    log('local player: ' .. tostring(name))
    run()
end

local function tick()
    if stopped then return end
    local ok, err = pcall(step)
    if not ok then
        stopped = true
        local restored = pcall(function() cleanup({ bForceImmediately = true, bNotifyUserSettings = false }) end)
        log('DISABLED: ' .. tostring(err) .. '; restored=' .. tostring(restored))
    end
end

if ModRef then
    ModRef.OnUnload = function()
        stopped = true
        pcall(function()
            ExecuteInGameThread(function()
                pcall(function() cleanup({ bForceImmediately = true, bNotifyUserSettings = false }) end)
            end)
        end)
    end
end

local started, err = pcall(LoopInGameThreadWithDelay, 1, tick)
if not started then log('DISABLED: ' .. tostring(err)); return end
log('v0.3.1 loaded; ' .. MODIFIER .. '+' .. TRIGGER .. ' -> 瞬身; ' .. MODIFIER .. '+LeftShift -> 普通闪避. Waiting for player.')
