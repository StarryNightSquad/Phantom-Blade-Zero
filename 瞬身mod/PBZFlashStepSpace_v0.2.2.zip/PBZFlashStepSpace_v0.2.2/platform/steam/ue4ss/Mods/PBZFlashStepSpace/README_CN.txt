=== PBZFlashStepSpace 0.2.2 ===
实机验证：2026-11-07，Steam build CL-301524 / UE 5.7.4，键鼠配置。

只做两件事：
  (1) 右键 + 空格   → 触发瞬身
  (2) 右键 + 左Shift → 不再触发瞬身
其它一切照旧：普通闪避、跳跃、格挡、武器技能、QTE/过场、存档都不动。

--------------------------------------------------
为什么不能"直接把 Shift 改成 Space"
--------------------------------------------------
瞬身和普通闪避共用同一个原生动作 /PBZDeflectSystem/Input/IA_Dodge，
区别只在该动作绑定行的 TriggerTag：
  · 普通闪避 = TriggerTag 不是 Ability.Action.Hun.SpecialDash
  · 瞬身     = TriggerTag 是   Ability.Action.Hun.SpecialDash（并要求按住右键的架势 tag）
所以直接改 IMC 的键位会把普通闪避一起改掉。

--------------------------------------------------
实现
--------------------------------------------------
(2) 把 IMC 里「IA_Dodge + LeftShift」的映射行，改指向一份私有副本
    （只携带"非瞬身行"），再 RequestRebuildControlMappings 生效。
    → Shift 依旧能普通闪避，但永远选不到瞬身行。
    → 原映射行没删，只换了 Action 引用；卸载/出错自动还原并重建。
(1) 自建 InputMappingContext（优先级 100），把 SpaceBar 映射到原生 IA_Dodge，
    并且只在按住右键时挂载 —— 空格单独按仍然是跳跃。

重建映射只在「右键/空格/左Shift 全部松开」时进行。
原因：重建会刷掉原生 Pressed 触发器，若按键正被按住，一次按下会被算成两次
（318 的源码里专门为此写了注释）。

--------------------------------------------------
安装
--------------------------------------------------
放到 PBZ\platform\steam\ue4ss\Mods\PBZFlashStepSpace\
应存在 Scripts\main.lua 与 enabled.txt，然后重启游戏。

--------------------------------------------------
验证（UE4SS.log 搜 [PBZFlashStepSpace]）
--------------------------------------------------
正常应该看到：
  v0.2.2 loaded; ...
  local player: ...
  dash source: /PBZCombatAsset/ActorData/Players/Hun/InputMap/AIM_Hun_Dash.AIM_Hun_Dash
  retarget /PBZInput/IMC_Deflect... key=LeftShift
  LeftShift 已改为只走普通闪避行: N 处映射
  space ctx ready; ...
  --- IA_Dodge 映射诊断 ---
    ... action=PLAIN ...   ← 被改指向私有副本的那几行
    ... action=NATIVE ...  ← 仍走原生动作的行

异常提示：
  WARN: 没找到 LeftShift->IA_Dodge 的映射行
      → 你的键位可能不是默认的 LeftShift，或映射存在别处；把 log 发我。
  WARN: RequestRebuildControlMappings failed
      → 重建失败，映射改动未生效（会重试）。
  DISABLED: ...
      → 出错并已整体还原。

--------------------------------------------------
性能（0.2.2 优化过）
--------------------------------------------------
重活只做一次，不进帧循环：
  · 扫描所有 IMC 的映射行、克隆绑定源、RequestRebuildControlMappings —— 安装时一次
  · 建空格 context、诊断 dump —— 一次

每帧只剩：
  · 1 次 pc.Pawn 读取 + 地址比较（不建字符串、不调 GetFullName）
  · 1 次 IsInputKeyDown（FKey 已预构造，不每帧 new FName）
  · 没按右键时直接 return：QTE 遍历、菜单/暂停判断全部跳过
  · QTE 遍历节流到每 6 帧一次（~100ms），且只在按住右键时执行
  · 没找到玩家时，找玩家节流到每 15 帧一次
  · consume 标记只在真的改过时才还原

对照：318 的 tick 也是每帧跑，并且每帧做 GetFullName、QTEManager 遍历和按键表构造。
本 Mod 的常驻开销比它低一个数量级。

--------------------------------------------------
已知的一处行为变化（不是 bug）
--------------------------------------------------
"右键 + 左Shift" 以前是瞬身，现在会走普通闪避那几行。
若那几行在"按住右键"状态下没有可匹配项，这个组合会变成无反应 ——
这正是"禁掉瞬身"的直接结果。

0.2.1/0.2.2 补了一个边界：如果「按住右键」那个条件桶里原本只有瞬身行，
摘掉之后桶就空了，按住右键会什么都按不出来。这种情况会**自动用普通行补齐**，
日志会打：
  条件桶 CharacterState....HoldingStanceKey 已无普通行，用普通行补上（保持按住右键可闪避）
补上之后：右键+Shift 稳定退回普通闪避，不会变成"没反应"。

另外：右键+空格 走的是原生 IA_Dodge，所以它**遵守原版条件**。
没学会瞬身时会同样只是普通闪避，学会之后才是瞬身 —— 不会强行解锁或强开。

--------------------------------------------------
注意
--------------------------------------------------
1. 别和 Nexus 418「瞬身禁用 / DisableFlashStep」同时用：
   那个 Mod 让瞬身永远无法发动，本 Mod 的右键+空格就会失效。
2. 不删技能、不改数值、不写存档、不碰 K2_CanActivateAbility。
3. 只在本地 Hun 角色、可操作状态下生效；菜单/暂停/过场/QTE 一律放行原版输入。
