-- PBZFlashStepSpace 0.2.2 | Steam build CL-301524 / UE 5.7.4
--
-- 只做两件事，其它一概不动：
--   (1) 新增  右键 + 空格   → 瞬身
--   (2) 禁用  右键 + 左Shift → 瞬身（左Shift 只剩普通闪避那套行）
--
-- 依据（本 build 已实测的输入结构，来自 318 的源码）：
--   瞬身与普通闪避共用同一个原生动作 /PBZDeflectSystem/Input/IA_Dodge，
--   区别只在该动作绑定行的 TriggerTag：
--     · 普通闪避 = TriggerTag 不等于 Ability.Action.Hun.SpecialDash
--     · 瞬身     = TriggerTag 等于 Ability.Action.Hun.SpecialDash（并要求按住右键的架势 tag）
--   IA_Dodge 的键盘映射行位于 IMC_Deflect：318 在键盘配置下用
--   assert(replaced>0) 强制要求改到这一行，否则直接报错，所以这一点可确定。
--
-- 做法：
--   (2) 把 IMC 里「IA_Dodge + LeftShift」的映射行改指向一份私有副本，
--       该副本只携带“非瞬身行”。于是 Shift 依旧能普通闪避，但永远选不到瞬身行。
--       原映射行本身没被删除，只换了 Action 引用，随时可还原。
--   (1) 自建 InputMappingContext（优先级 100），把 SpaceBar 映射到原生 IA_Dodge，
--       并且只在按住右键时挂载 —— 空格平时仍然是跳跃。
--   不删技能、不改数值/存档、不碰 K2_CanActivateAbility、不动其它按键。
local MOD = 'PBZFlashStepSpace'
local TRIGGER = 'SpaceBar'
local MODIFIER = 'RightMouseButton'
local SUPPRESS_KEY = 'LeftShift' -- 要移除瞬身语义的物理键（默认键位）
local PRIORITY = 100
local DEVICE_ID = 1 -- 键盘鼠标
local DODGE_PATH = '/PBZDeflectSystem/Input/IA_Dodge.IA_Dodge'
local DEFLECT_CTX = '/PBZInput/IMC_Deflect.IMC_Deflect'
local DEFAULT_CTX = '/PBZInput/IMC_Default.IMC_Default'
local BASE_BINDING = '/PBZCombatAsset/ActorData/Players/Hun/InputMap/AIM_Hun_Dash.AIM_Hun_Dash'
local SPECIAL = 'Ability.Action.Hun.SpecialDash'

local function log(s) print('[' .. MOD .. '] ' .. s .. '\n') end
if type(LoopInGameThreadWithDelay) ~= 'function' then
    log('DISABLED: game-thread timer unavailable')
    return
end

local function valid(o) return o ~= nil and o:IsValid() end
local function equal(a, b) return valid(a) and valid(b) and a:GetAddress() == b:GetAddress() end
local function unwrap(v) local ok, x = pcall(function() return v:get() end); return ok and x or v end
local function key(name) return { KeyName = FName(name) } end
local function full(o) local n = o:GetFullName(); return n:match('^%S+ (.+)$') or n end
local function each(a, fn)
    if a == nil then return end
    if type(a) == 'table' and type(a.ForEach) ~= 'function' then
        for i, v in ipairs(a) do fn(i, v) end
    else
        a:ForEach(function(i, v) fn(i, unwrap(v)) end)
    end
end
local function array(a)
    local r = {}
    each(a, function(_, v) if v ~= nil then r[#r + 1] = v end end)
    return r
end

-- 帧循环里反复用到的 FKey 预先构造好：FName 走全局名字表，
-- 每帧新建一次是纯浪费，这里只建一次。
local K_MODIFIER = { KeyName = FName(MODIFIER) }
local K_TRIGGER = { KeyName = FName(TRIGGER) }
local K_SUPPRESS = { KeyName = FName(SUPPRESS_KEY) }

local options = { bIgnoreAllPressedKeysUntilRelease = true, bForceImmediately = true, bNotifyUserSettings = false }
local pc, pawn, pawnFull, component, sub, stats, dodge, outer, serial
local spaceCtx, plainAction, plainBindings
local mapped, stopped, diagnosed = false, false, false
local guardInstalled, retargeted = false, 0
local consumeSaved, consumeDirty

local function make(class, label, template)
    local cl = StaticFindObject(class)
    assert(valid(cl), 'Missing class ' .. class)
    serial = (serial or 0) + 1
    local o = StaticConstructObject(cl, outer, FName('PBZFS_' .. label .. '_' .. serial, EFindName.FNAME_Add),
        0x40, 0x40000000, false, false, template)
    assert(valid(o), 'Cannot construct ' .. label)
    return o
end

local function playerFrom(c)
    local ok, p, name = pcall(function()
        if not valid(c) or not c:IsLocalController() then return end
        local p = c.Pawn
        if not valid(p) then return end
        local n = p:GetFullName()
        if n:find('PersistentLevel.BP_Renewal_Hun_C_', 1, true) then return p, n end
    end)
    if ok and p then return c, p, name end
end

local function currentPlayer()
    local c, p, name = playerFrom(pc)
    if c then return c, p, name end
    for _, candidate in ipairs(FindAllOf('PlayerController') or {}) do
        c, p, name = playerFrom(candidate)
        if c then return c, p, name end
    end
end

local function findSub()
    for _, s in ipairs(FindAllOf('EnhancedInputLocalPlayerSubsystem') or {}) do
        if valid(s) and equal(s:GetOuter(), pc.Player) then return s end
    end
end

local function ensureRefs()
    if not (valid(pc) and valid(pawn)) then return false end
    if not valid(stats) then
        stats = StaticFindObject('/Script/Engine.Default__GameplayStatics')
        if not valid(stats) then return false end
    end
    if not valid(dodge) then
        dodge = StaticFindObject(DODGE_PATH)
        if not valid(dodge) then return false end
    end
    if not valid(outer) then
        outer = pc.Player
        if not valid(outer) then return false end
    end
    if not valid(component) then
        component = pawn:GetAbilityInputComponent()
        if not valid(component) then return false end
    end
    if not valid(sub) then
        sub = findSub()
        if not valid(sub) then return false end
    end
    -- 原生动作还没注册到能力输入组件上，说明还没进可操作状态。
    if not component.InputBindings:Contains(dodge) then return false end
    return true
end

-- ==================== (2) 让左Shift不再触发瞬身 ====================

-- 只保留非瞬身行。读不出 TriggerTag 的行一律保留：宁可多留，不可误删。
-- fallback：条件桶里一条普通行都不剩时，用 NormalData 的普通行补上。
--   原因：瞬身行挂在「按住右键」的条件桶里。若该桶原本只有瞬身行，
--   摘掉后桶就空了，按住右键反而变得什么都按不出来 —— 那不是"禁用瞬身"，
--   而是把闪避一起弄坏了。补上后：右键+Shift 稳定退回普通闪避。
local function filterRows(data, keepSpecial, fallback)
    local left = 0
    for _, field in ipairs({ 'Actions', 'Combos', 'InterruptLower' }) do
        local kept = {}
        each(data[field], function(_, row)
            local ok, tag = pcall(function() return row.TriggerTag.TagName:ToString() end)
            local isSpecial = ok and tag == SPECIAL
            if isSpecial == keepSpecial then kept[#kept + 1] = row end
        end)
        data[field] = kept
        left = left + #kept
    end
    if left == 0 and fallback then
        for _, field in ipairs({ 'Actions', 'Combos', 'InterruptLower' }) do
            data[field] = array(fallback[field])
        end
        return 'filled'
    end
end

local function cloneBinding(source, label)
    local copy = make('/Script/SGameInputSystem.InputActionBinding', label, source)
    each(copy.Bindings, function(_, entry)
        filterRows(entry.NormalData, false, nil)
        entry.TagConditionData:ForEach(function(k, v)
            local how = filterRows(unwrap(v), false, entry.NormalData)
            if how == 'filled' then
                local ok, name = pcall(function() return unwrap(k).TagName:ToString() end)
                log('  条件桶 ' .. tostring(ok and name or k) .. ' 已无普通行，用普通行补上（保持按住右键可闪避）')
            end
        end)
    end)
    return copy
end

-- 枚举可能存放 IA_Dodge 映射行的容器：当前生效的上下文 + 两个关键 IMC 资产；
-- 每个容器再展开 MappingProfileOverrides（游戏内键位档案就存在这里）。
local function collectRowSets()
    local sets, seen = {}, {}
    local function addContext(c, label)
        if not valid(c) or seen[c:GetAddress()] then return end
        seen[c:GetAddress()] = true
        sets[#sets + 1] = { rows = c.DefaultKeyMappings.Mappings, label = label .. ' default' }
        pcall(function()
            c.MappingProfileOverrides:ForEach(function(k, p)
                local pr = unwrap(p)
                if valid(pr) then
                    sets[#sets + 1] = { rows = pr.Mappings, label = label .. ' profile=' .. tostring(k) }
                end
            end)
        end)
    end
    local applied = 0
    local function collect(field)
        local good, map = pcall(function() return pc.PlayerInput[field] end)
        if good and map then
            map:ForEach(function(k)
                local c = unwrap(k)
                if valid(c) and not equal(c, spaceCtx) then applied = applied + 1; addContext(c, full(c)) end
            end)
        end
    end
    collect('AppliedInputContextData')
    if applied == 0 then collect('AppliedInputContexts') end
    for _, path in ipairs({ DEFLECT_CTX, DEFAULT_CTX }) do
        local c = StaticFindObject(path)
        if valid(c) then addContext(c, full(c)) end
    end
    return sets
end

-- 重建玩家映射。必须等按键全部松开再做：重建会刷掉原生 Pressed 触发器，
-- 若此时按键正被按住，一次物理按下会被算成两次。318 的源码里专门为此写了注释。
local function rebuild()
    if not valid(sub) then return false end
    local ok = pcall(function() sub:RequestRebuildControlMappings(options, DEVICE_ID) end)
    if not ok then log('WARN: RequestRebuildControlMappings failed') end
    return ok
end

local function keysReleased()
    for _, k in ipairs({ K_MODIFIER, K_TRIGGER, K_SUPPRESS }) do
        local ok, down = pcall(function() return pc:IsInputKeyDown(k) end)
        if not ok or down then return false end
    end
    return true
end

local function installShiftGuard()
    if guardInstalled then return true end
    if not valid(dodge) or not valid(component) or not valid(sub) or not keysReleased() then return false end
    if not component.InputBindings:Contains(dodge) then return false end

    local sources = array(component.InputBindings:Find(dodge):get().Bindings)
    if #sources == 0 then return false end
    local hasBase = false
    for _, s in ipairs(sources) do
        if full(s) == BASE_BINDING then hasBase = true end
        log('dash source: ' .. full(s))
    end
    if not hasBase then log('WARN: base dash source not found; using all ' .. #sources .. ' source(s)') end

    -- 同一动作允许挂多份绑定源（原生就是这么累积的），所以每个源都复制一份。
    plainAction = make('/Script/EnhancedInput.InputAction', 'PlainDodge', dodge)
    plainBindings = {}
    for _, s in ipairs(sources) do
        local b = cloneBinding(s, 'PlainDodgeBind')
        component:RegisterActionInputBindings({ [plainAction] = b })
        plainBindings[#plainBindings + 1] = b
    end
    guardInstalled = true

    retargeted = 0
    for _, set in ipairs(collectRowSets()) do
        each(set.rows, function(_, row)
            pcall(function()
                if valid(row.Action) and equal(row.Action, dodge)
                    and row.Key.KeyName:ToString() == SUPPRESS_KEY then
                    row.Action = plainAction
                    retargeted = retargeted + 1
                    log('  retarget ' .. set.label .. ' key=' .. SUPPRESS_KEY)
                end
            end)
        end)
    end
    rebuild()
    if retargeted > 0 then
        log(SUPPRESS_KEY .. ' 已改为只走普通闪避行: ' .. retargeted .. ' 处映射')
    else
        log('WARN: 没找到 ' .. SUPPRESS_KEY .. ' -> IA_Dodge 的映射行；该键的瞬身可能仍然存在')
    end
    return true
end

local function uninstallShiftGuard()
    if not guardInstalled then return end
    local restored = 0
    if valid(plainAction) then
        for _, set in ipairs(collectRowSets()) do
            each(set.rows, function(_, row)
                pcall(function()
                    if valid(row.Action) and equal(row.Action, plainAction) then
                        row.Action = dodge; restored = restored + 1
                    end
                end)
            end)
        end
    end
    if valid(component) and valid(plainAction) and plainBindings then
        for _, b in ipairs(plainBindings) do
            if valid(b) then
                pcall(function() component:UnregisterActionInputBindings({ [plainAction] = b }) end)
            end
        end
    end
    guardInstalled = false
    plainAction, plainBindings, retargeted = nil, nil, 0
    rebuild()
    log(SUPPRESS_KEY .. ' 映射已还原: ' .. restored .. ' 处')
end

-- ==================== (1) 右键 + 空格 → 瞬身 ====================

-- MapKey 生成的行没有触发器；不补 Pressed 会按住即每帧触发（连滚）。
local function addPressedMap(ctx, action, keyName, label)
    ctx:MapKey(action, key(keyName))
    local mappings = ctx.DefaultKeyMappings.Mappings
    local count = #mappings
    local pressed = make('/Script/EnhancedInput.InputTriggerPressed', label)
    local hit = false
    each(mappings, function(i, m)
        if i == count then
            local actual = m.Key.KeyName:ToString()
            if not equal(m.Action, action) then log('WARN: appended action mismatch for ' .. keyName) end
            if actual ~= keyName then log('WARN: appended key is ' .. actual .. ', expected ' .. keyName) end
            m.Triggers = { pressed }
            m.Modifiers = {}
            m.bShouldBeIgnored = false
            m.bHasAlwaysTickTrigger = false
            hit = true
        end
    end)
    if not hit then log('WARN: mapping for ' .. keyName .. ' was not appended') end
end

local function ensureSpaceCtx()
    if valid(spaceCtx) then return true end
    local default = StaticFindObject(DEFAULT_CTX)
    if not valid(default) or not valid(dodge) then return false end
    spaceCtx = make('/Script/EnhancedInput.InputMappingContext', 'Ctx')
    -- 跟随默认 gameplay 上下文的输入模式过滤，避免在 UI/菜单里也生效。
    spaceCtx.InputModeFilterOptions = default.InputModeFilterOptions
    spaceCtx.InputModeQueryOverride = default.InputModeQueryOverride
    addPressedMap(spaceCtx, dodge, TRIGGER, 'SpacePressed')
    local ok, consume = pcall(function() return dodge.bConsumeInput end)
    log('space ctx ready; native bConsumeInput=' .. tostring(ok and consume or '?'))
    return true
end

-- 一次性诊断：dump 当前所有 IMC 里 IA_Dodge 的键位与绑定行，便于核对结果。
local function rowTags(row)
    local t = {}
    local ok = pcall(function()
        each(row.NormalData.Actions, function(_, r) t[#t + 1] = r.TriggerTag.TagName:ToString() end)
    end)
    return ok and table.concat(t, '|') or '?'
end

local function scanContext(c, label)
    pcall(function()
        each(c.DefaultKeyMappings.Mappings, function(_, row)
            if valid(row.Action) and (equal(row.Action, dodge) or equal(row.Action, plainAction)) then
                log('  ' .. label .. ' key=' .. row.Key.KeyName:ToString()
                    .. ' action=' .. (equal(row.Action, plainAction) and 'PLAIN' or 'NATIVE')
                    .. ' tags=' .. rowTags(row))
            end
        end)
        c.MappingProfileOverrides:ForEach(function(k, p)
            local pr = unwrap(p)
            each(pr.Mappings, function(_, row)
                if valid(row.Action) and (equal(row.Action, dodge) or equal(row.Action, plainAction)) then
                    log('  ' .. label .. ' profile=' .. tostring(k) .. ' key=' .. row.Key.KeyName:ToString()
                        .. ' action=' .. (equal(row.Action, plainAction) and 'PLAIN' or 'NATIVE')
                        .. ' tags=' .. rowTags(row))
                end
            end)
        end)
    end)
end

local function diagnose()
    if diagnosed then return end
    diagnosed = true
    local ok, err = pcall(function()
        log('--- IA_Dodge 映射诊断 ---')
        for _, set in ipairs(collectRowSets()) do
            log(' ' .. set.label)
            each(set.rows, function(_, row)
                if valid(row.Action) and (equal(row.Action, dodge) or equal(row.Action, plainAction)) then
                    log('   key=' .. row.Key.KeyName:ToString()
                        .. ' action=' .. (equal(row.Action, plainAction) and 'PLAIN' or 'NATIVE')
                        .. ' tags=' .. rowTags(row))
                end
            end)
        end
        log('--- 诊断结束 ---')
    end)
    if not ok then log('diagnose failed: ' .. tostring(err)) end
end

-- ==================== 挂载 / 卸载 ====================

-- QTE 检测要遍历 QTEManager，是这一帧里最贵的一步。
-- 节流到每 6 帧一次（~100ms），并且只在按住右键要挂载时才查。
local frame = 0
local qteCached, qteAt = false, -100
local function qteActive()
    if frame - qteAt < 6 then return qteCached end
    qteAt = frame
    local ok, found = pcall(function()
        if not valid(pc.QTEManager) then return false end
        local f = false
        pc.QTEManager:ForEach(function(_, v) if valid(unwrap(v)) then f = true end end)
        return f
    end)
    qteCached = (ok and found) or false
    return qteCached
end

local function blockedReason()
    if not valid(pc) then return 'player unavailable' end
    if pc.bShowMouseCursor then return 'cursor visible' end
    if pc:IsMoveInputIgnored() or pc:IsLookInputIgnored() then return 'input reserved' end
    if stats and stats:IsGamePaused(pc) then return 'paused' end
    if qteActive() then return 'qte' end
    return nil
end

local function unmount(opts)
    if mapped and valid(sub) and valid(spaceCtx) then
        pcall(function() sub:RemoveMappingContext(spaceCtx, opts or options) end)
    end
    mapped = false
    -- 只有真的改过才还原，避免每帧都做一次 pcall + 属性比对。
    if consumeDirty and consumeSaved and valid(dodge) then
        pcall(function()
            if dodge.bConsumeInput ~= consumeSaved.value then dodge.bConsumeInput = consumeSaved.value end
        end)
        consumeDirty = false
    end
end

local function mount()
    if mapped or not valid(spaceCtx) or not valid(sub) then return end
    if valid(dodge) then
        pcall(function()
            if not consumeSaved then consumeSaved = { value = dodge.bConsumeInput == true } end
            if dodge.bConsumeInput ~= true then dodge.bConsumeInput = true; consumeDirty = true end
        end)
    end
    sub:AddMappingContext(spaceCtx, PRIORITY, options)
    mapped = true
end

local function cleanup(opts)
    unmount(opts)
    uninstallShiftGuard()
    spaceCtx, component, sub = nil, nil, nil
end

-- 热路径：只在状态真的变化时才碰引擎。
local function run()
    if not ensureRefs() then return end
    if not valid(spaceCtx) then if not ensureSpaceCtx() then return end end
    if not guardInstalled then installShiftGuard() end

    -- 没按右键时直接退出：QTE 遍历、菜单状态查询全部跳过。
    if not pc:IsInputKeyDown(K_MODIFIER) then
        unmount()
        return
    end
    if blockedReason() then
        unmount()
        return
    end
    mount()
    diagnose()
end

local function step()
    frame = frame + 1

    -- 1) 已有玩家：纯地址比较，不调用 GetFullName、不生成任何字符串。
    if valid(pc) and valid(pawn) then
        local ok, current = pcall(function() return pc.Pawn end)
        if ok and valid(current) and equal(current, pawn) then
            return run()
        end
        -- 玩家消失或换人：立刻卸载，别等到下一轮扫描。
        cleanup()
        pc, pawn, pawnFull = nil, nil, nil
        return
    end

    -- 2) 没有玩家：每 15 帧找一次（启动时 frame==1 立即找）。
    if frame % 15 ~= 1 then return end
    local c, p, name = currentPlayer()
    if not c then
        if mapped or valid(spaceCtx) or guardInstalled then cleanup() end
        return
    end
    pc, pawn, pawnFull = c, p, name
    log('local player: ' .. tostring(name))
    run()
end

local function tick()
    if stopped then return end
    local ok, err = pcall(step)
    if not ok then
        stopped = true
        local restored = pcall(function() cleanup({ bForceImmediately = true, bNotifyUserSettings = false }) end)
        log('DISABLED: ' .. tostring(err) .. '; restored=' .. tostring(restored))
    end
end

if ModRef then
    ModRef.OnUnload = function()
        stopped = true
        pcall(function()
            ExecuteInGameThread(function()
                pcall(function() cleanup({ bForceImmediately = true, bNotifyUserSettings = false }) end)
            end)
        end)
    end
end

local started, err = pcall(LoopInGameThreadWithDelay, 1, tick)
if not started then log('DISABLED: ' .. tostring(err)); return end
log('v0.2.2 loaded; ' .. MODIFIER .. '+' .. TRIGGER .. ' -> 瞬身; ' .. MODIFIER .. '+LeftShift -> 普通闪避. Waiting for player.')
