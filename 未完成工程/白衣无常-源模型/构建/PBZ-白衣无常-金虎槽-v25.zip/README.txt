白衣无常 · 明末 → 影之刃零 外观移植  v24
================================================

装到哪里
--------
把 ProjectPBZ 文件夹整个放进游戏根目录（和 ProjectPBZ.exe 同级）：
    <游戏根目录>\ProjectPBZ\Content\Paks\~mods\BaiyiAppearance\
        zzzzzzzz_PBZ_Baiyi_3002_P.pak    ← 仅占位（让 utoc/ucas 能被挂载），无任何脚本
        zzzzzzzz_PBZ_Baiyi_3002_P.utoc   ← 资产索引（含外观表）
        zzzzzzzz_PBZ_Baiyi_3002_P.ucas   ← 网格 / 材质 / 贴图 / 外观表

v24 改了什么
------------
只改材质实例的参数，模型、骨骼、外观表、贴图全部沿用 v23。

对比游戏本体自己的材质实例后，把 27 个材质实例砍到和官方一致：
    官方 MI_ZeroHun_Cloth_01_b（同一个母材质 MAI_Equipment_Mask）
        Albedo / Mix / Normal / RefractionDepthBias  ← 只设这几个
    我们 v23 设了 15 个，多出来的：
        Albedo Controls / Albedo Overlay / Roughness Channel / AO Min /
        Metallic Min,Max / Normal Strength / Roughness Exponent,Max,Min / Specular
    其中 Albedo Controls=(1,1,1,1) + Albedo Overlay=(0.5,0.5,0.5)
    等于把 50% 灰叠在反照率上，这正是"全身均匀灰"的形态。
    OpacityThreshold 在真母材质里根本不存在（全文件搜索 = 无），设了也无效，一并去掉。

所以 v24 的材质实例只设 Albedo / Normal / Mix 三个贴图。

内容
----
上装   原版白衣无常（肩甲、骷髅护肩、上臂骨饰、肘部护臂、裙摆、腰间红穗）
小臂手 明末女眷套：前臂裸肤 + 腕上红绳 + 长指甲
下装   细带高跟光腿（无内裤），白色细带高跟
头     织绣海寇头部，马尾缩短到 0.34 倍
鞋底   Zmin = -4.360，累计抬高 13mm

已知事项
--------
· 外观表是「整表覆盖」，游戏下次更新若新增外观行，需要重新同步
· 不含引擎资产、不含自建着色器、不含任何 JavaScript
· 只有官方预留的已解锁 Codex 槽位能看到并穿上，未解锁的显示灰模属正常

生成日期 2026-11-04
